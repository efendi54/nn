#include <assert.h>
#include <vector>
#include <algorithm>

#include "bits.h"

using namespace std;

template<>
BB64 Lsb<BB64>(const BB64 &x)
{
#pragma warning(disable:4146)
  return BB64(x.to_ullong() & -(x.to_ullong()));
#pragma warning(default:4146)
}

template<>
BB32 Lsb<BB32>(const BB32 &x)
{
#pragma warning(disable:4146)
  return BB32(x.to_ullong() & -(x.to_ullong()));
#pragma warning(default:4146)
}

template<>
BB64 Msb<BB64>(const BB64 &x)
{
  BB64 b(x);
  b |= (b >> 1);
  b |= (b >> 2);
  b |= (b >> 4);
  b |= (b >> 8);
  b |= (b >> 16);
  b |= (b >> 32);
  return(b & ~(b >> 1));
}

template<>
size_t Idx<BB64>(const BB64 &x)
{
  static const BB64 s_DEBRUIJN64(0x03F79D71B4CB0A89);
  static const size_t s_bit_hash64[64] = 
  {  
    0,  1, 48,  2, 57, 49, 28,  3,
    61, 58, 50, 42, 38, 29, 17,  4,
    62, 55, 59, 36, 53, 51, 43, 22,
    45, 39, 33, 30, 24, 18, 12,  5,
    63, 47, 56, 27, 60, 41, 37, 16,
    54, 35, 52, 21, 44, 32, 23, 11,
    46, 26, 40, 15, 34, 20, 31, 10,
    25, 14, 19,  9, 13,  8,  7,  6
  };
  const BB64 p = BB64((x.to_ullong() * s_DEBRUIJN64.to_ullong())) >> 58;
  return s_bit_hash64[p.to_ullong()];
}

template<>
void ReverseBits(unsigned char &x)
{
  x = (((x & 0xaa) >> 1) | ((x & 0x55) << 1));
  x = (((x & 0xcc) >> 2) | ((x & 0x33) << 2));
  x = (((x & 0xf0) >> 4) | ((x & 0x0f) << 4));
}
