#include <iostream>
#include <map>
#include "board.h"
using namespace std;

int main(int argc, char *argv[])
{
  Att();
  return 0;
}

