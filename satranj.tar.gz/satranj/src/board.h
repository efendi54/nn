#pragma once
#include "bits.h"

enum E_Color {eWhite,eBlack,eColors};
enum E_Figure{ePawn,eSpringer,eBishop,eRook,eQueen,eKing,eFigures};

struct T_Board
{
  T_Board();
  BB64 t_board[eColors][eFigures];
  BB64 t_figs[eColors];
  E_Color t_stm;
  E_Color t_check;
};
  
void Print(const T_Board &b, 
           const E_Color view=eWhite);

void Print(const BB64 &b); 
void Att(void); 
