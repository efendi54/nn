#include <iostream>
#include <bitset>

typedef std::bitset<64> BB64;
typedef std::bitset<32> BB32;

void InitBits(void);

template<typename T>
T Lsb(const T &b);

template<typename T>
T Msb(const T &b);

template<typename T>
size_t Idx(const T &b);

template<typename T>
void ReverseBits(T &b);
