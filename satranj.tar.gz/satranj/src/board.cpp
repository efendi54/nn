#include <iostream>
#include <map>
#include <algorithm>
#include <assert.h>
#include "board.h"

using namespace std;

T_Board::T_Board()
{
  t_board[eWhite][ePawn] = BB64(0xff00);
  t_board[eWhite][eSpringer] = BB64(0x42);
  t_board[eWhite][eBishop] = BB64(0x24);
  t_board[eWhite][eRook] = BB64(0x81);
  t_board[eWhite][eQueen] = BB64(0x10);
  t_board[eWhite][eKing] = BB64(0x8);

  for (size_t f=ePawn; f<eFigures; ++f)
  {
    t_board[eBlack][f] = t_board[eWhite][f];
    t_board[eBlack][f] <<= (f==ePawn)?40:56;

    t_figs[eWhite] |= t_board[eWhite][f];
    t_figs[eBlack] |= t_board[eBlack][f];
  }

  t_stm = eWhite;
  t_check = eColors;
}

size_t SqMap64(size_t idx)
{
  assert(idx<64);
  static const size_t sq_map[64] = 
  {
    56,57,58,59,60,61,62,63,
    48,49,50,51,52,53,54,55,
    40,41,42,43,44,45,46,47,
    32,33,34,35,36,37,38,39,
    24,25,26,27,28,29,30,31,
    16,17,18,19,20,21,22,23,
     8, 9,10,11,12,13,14,15,
     0, 1, 2, 3, 4, 5, 6, 7
  };
  return sq_map[idx];
}

void Print(const T_Board &b, const E_Color view)
{
  assert(view < eColors);

  const string col_str = "WB?";
  const string fig_str = "PSBRQKpsbrqk.";
  cout << " ________ " << endl;
  for (size_t r=0; r<8; ++r)
  {
    string row_str = "|";
    for (size_t c=0; c<8; ++c)
    {
      size_t pos = (view == eWhite)?(SqMap64(r*8+c)):(63-SqMap64(r*8+c)); 
      if ((b.t_figs[eWhite] | 
           b.t_figs[eBlack]).test(pos))
        for (size_t f=ePawn; f<eFigures; ++f)
        {
          if ((b.t_board[eWhite][f] | 
               b.t_board[eBlack][f]).test(pos))
          {
            row_str += fig_str[f + (b.t_board[eBlack][f].test(pos) * 6)];
            break;
          }
        }
      else
        row_str += ".";
    }
    row_str += "|";
    cout << row_str << ((view==eWhite)?(8-r):(r+1)) << endl;
  }
  cout << " --------   STM=" << 
     col_str[b.t_stm] << ", CHK=" <<
     col_str[b.t_check] << endl << 
     ((view==eWhite)?" ABCDEFGH":" HGFEDCBA") << endl; 
}

void Print(const BB64 &b)
{
  cout << " ________ " << endl;
  for (size_t r=0; r<8; ++r)
  {
    string row_str = "|";
    for (size_t c=0; c<8; ++c)
    {
      //const size_t pos = 63 - ((r*8) + 7 - c);
      const size_t pos = SqMap64(r*8+c);
      row_str += (b.test(pos))?'x':'.';
    }
    row_str += "|";
    cout << row_str << endl; 
  }
  cout << " --------" << endl;
}

void Att(void)
{
  for(size_t pos=0; pos<8; ++pos)     // column pos
  for(size_t occ=0; occ<0x100; ++occ) // occ combs
  {
    bitset<8> row(occ|0x81);
    bitset<8> left = row, right = row;

    // clear out all bits below / upper pos (including pos) ..
    bitset<8>left_mask  = left  & bitset<8>(~((0x1 << (pos+1))-1));
    bitset<8>right_mask = right & bitset<8>(((0x1 << (pos))-1));

    // for left find lsb and fill up from pos+1 until lsb
    bitset<8> tmp_left = (0x1 << Idx<BB64>(Lsb<BB64>(left_mask.to_ulong())) + 1) - 1;
    tmp_left &= ~(bitset<8>((0x1 << pos)-1));

    bitset<8> tmp_right = ~bitset<8>((Msb<BB64>(right_mask.to_ulong()) << 1) - 1);
    tmp_right &= bitset<8>((0x1 << (pos+1)) -1);
  
    cout << endl << "pos  = " << ~bitset<8>(0x1<<pos) << endl;
    cout << "row  = " << row << endl;
    cout << "left = " << tmp_left << endl;
    cout << "right= " << tmp_right << endl;
    int stop = 0;
  }
}

