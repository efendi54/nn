#include <iostream>
#include "bits.h"

using namespace std;

int main(int argc, char *argv[])
{
  srand(time(NULL));
  InitBits();

  U64 test = 0x60050;
  cout << std::hex << "test = 0x" << test << endl; 
  cout << "bit-cnt : " << BitCount64(test) << endl;
  cout << "lsb : " << std::hex << Lsb64(test) << endl;
  cout << "msb : " << Msb64(test) << endl;

  return 0;
}
