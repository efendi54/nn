#include "bits.h"

//#define BITPARALLEL

// ************************************************************************************
// 0000 0011 1111 0111 1001 1101 0111 0001 1011 0100 1100 1011 0000 1010 1000 1001
//** \def debruijn sequence of length 6 */
#define DEBRUIJN64 (U64)(0x03F79D71B4CB0A89)

/** \def debruijn sequence of length 5 */
#define DEBRUIJN32 (ulong)(0x077CB531UL)

/** \def functional macro checking if bit is set in unsigned 64-bit b at position n */
#define BITSET(b, n)  ((b>>n) & ((U64)1L))

//** \def functional macro returning unsigned 64-bit value with bit set on position n */
#define SETBIT64(n)     ((U64)    (0x1)<<(n))

/** \def functional macro returning unsigned 32-bit value with bit set on position n */
#define SETBIT32(n)     ((ulong)  (0x1)<<(n))

// ************************************************************************************
// the following macro definitions are used to count set bits in given unsigned 32-bit value x
#define TWO(c)      ((U64)(0x1u)<<(c))
#define MASK(c)     (((ulong)(-1)) / (TWO(TWO(c)) + 1u))
#define COUNT(x,c)  (((x) & MASK(c)) + (((x)>>TWO(c)) & MASK(c)))

#define MASK_01010101 (((unsigned int)(-1))/3)
#define MASK_00110011 (((unsigned int)(-1))/5)
#define MASK_00001111 (((unsigned int)(-1))/17)
// ************************************************************************************


/** \def functional macro counting the number of set bits in given unsigned 32-bit value x */
#define BITCOUNT_T32(x) ( bitCountTab8[(x)      & 0xffu] +  \
                          bitCountTab8[(x>>8)   & 0xffu] +  \
                          bitCountTab8[(x>>16)  & 0xffu] +  \
                          bitCountTab8[(x>>24)  & 0xffu]  )


// the following macro definitions are used to calculate most significant bit out of given unsigned 32-bit value x
#define MSB32_TEMP0(x) (x | (x >> 1))
#define MSB32_TEMP1(x) (MSB32_TEMP0(x) | (MSB32_TEMP0(x) >> 2))
#define MSB32_TEMP2(x) (MSB32_TEMP1(x) | (MSB32_TEMP1(x) >> 4))
#define MSB32_TEMP3(x) (MSB32_TEMP2(x) | (MSB32_TEMP2(x) >> 8))
#define MSB32_TEMP4(x) (MSB32_TEMP3(x) | (MSB32_TEMP3(x) >> 16))
#define MSB32_TEMP5(x) (x & ~(x >> 1))
#define MSB32(x)       MSB32_TEMP5(MSB32_TEMP4(x))

// ************************************************************************************


/** \brief hash-lookup-table used to lookup bit-positions of single set bits of unsigned 64-bit values */
ushort bithash64[64]    ;

/** \brief hash-lookup-table used to lookup bit-positions of single set bits of unsigned 32-bit values */
ushort bithash32[32]    ;

/** \brief hash-lookup-table used to count number of set bits of unsigned 8-bit values */
uchar bitCountTab8[256] ;


///////////////////////////////////////////////
/**
 * Counts the number of set bits in unsigned 32-bit value using parallel-count-algorithm (no lookup-tables used)
 * \param The unsigned 32-bit value containing bits to be counted
 * \return Number of bits in given value
 */
size_t BitPCount32(ulong n)
///////////////////////////////////////////////
{
  n = COUNT(n, 0);
  n = COUNT(n, 1);
  n = COUNT(n, 2);
  n = COUNT(n, 3);
  n = COUNT(n, 4);
  return static_cast<size_t>(n);
}

///////////////////////////////////////////////
/**
 * Counts the number of set bits in unsigned 64-bit value using parallel-count-algorithm (no lookup-tables used)
 * \param The unsigned 64-bit value containing bits to be counted
 * \return Number of bits in given value
 */
size_t BitPCount64(U64 n)
///////////////////////////////////////////////
{
  n = COUNT(n, 0);
  n = COUNT(n, 1);
  n = COUNT(n, 2);
  n = COUNT(n, 3);
  n = COUNT(n, 4);
  n = COUNT(n, 5);
  return static_cast<size_t>(n);
}

///////////////////////////////////////////////
/**
 * @brief Initializes all internals 
 */
void InitBits()
///////////////////////////////////////////////
{
  for(ushort i=0;i<64;i++)
    bithash64[(DEBRUIJN64<<i)>>58] = i;
  for(ushort i=0;i<32;i++)
    bithash32[(DEBRUIJN32<<i)>>27] = i;

  for(ulong i=0;i<256;i++)
  {
    uchar bc = BitPCount32(i);
    bitCountTab8[i] = bc;
  }
}

///////////////////////////////////////////////
/**
 * Counts the number of set bits in unsigned 32-bit value (lookup-tables are used)
 * \param The unsigned 32-bit value containing bits to be counted
 * \return Number of bits in given value
 */
size_t BitTCount32(ulong x)
///////////////////////////////////////////////
{
  return static_cast<size_t>(
      bitCountTab8[(x)     & 0xffu] + 
      bitCountTab8[(x>>8)  & 0xffu] +
      bitCountTab8[(x>>16) & 0xffu] +
      bitCountTab8[(x>>24) & 0xffu] );

}

///////////////////////////////////////////////
/**
 * Counts the number of set bits in unsigned 64-bit value (lookup-tables are used)
 * \param The unsigned 64-bit value containing bits to be counted
 * \return Number of bits in given value
 */
size_t BitTCount64(U64 x)
///////////////////////////////////////////////
{
  return static_cast<size_t>(
      bitCountTab8[(x)     & 0xffu] + 
      bitCountTab8[(x>>8)  & 0xffu] +
      bitCountTab8[(x>>16) & 0xffu] +
      bitCountTab8[(x>>24) & 0xffu] + 
      bitCountTab8[(x>>32) & 0xffu] + 
      bitCountTab8[(x>>40) & 0xffu] +
      bitCountTab8[(x>>48) & 0xffu] +
      bitCountTab8[(x>>56) & 0xffu] );
}

///////////////////////////////////////////////
/**
 * Counts the number of set bits in unsigned 64-bit value.
 * \param The unsigned 64-bit value containing bits to be counted
 * \return Number of bits in given value
 */
size_t BitCount64(U64 n)
///////////////////////////////////////////////
{
#ifdef BITPARALLEL
  return BitPCount64(n);
#else
  return BitTCount64(n);
#endif
}

///////////////////////////////////////////////
/**
 * Counts the number of set bits in unsigned 32-bit value.
 * \param The unsigned 32-bit value containing bits to be counted
 * \return Number of bits in given value
 */
size_t BitCount32(ulong n)
///////////////////////////////////////////////
{
#ifdef BITPARALLEL
  return BitPCount32(n);
#else
  return BitTCount32(n);
#endif
}

///////////////////////////////////////////////
/**
 * Determins the least significant bit set of given unsigned 64-bit value
 * \param The unsigned 64-bit value 
 * \return Least significant bit set of given unsigned 64-bit value
 */
U64 Lsb64(register U64 x)
///////////////////////////////////////////////
{
#pragma warning(disable:4146)
  return x&-x;
#pragma warning(default:4146)
}

///////////////////////////////////////////////
/**
 * Determins the least significant bit set of given unsigned 32-bit value
 * \param The unsigned 32-bit value 
 * \return Least significant bit set of given unsigned 32-bit value
 */
ulong Lsb32(register ulong x)
///////////////////////////////////////////////
{
#pragma warning(disable:4146)
 return x&-x;
#pragma warning(default:4146)
}

///////////////////////////////////////////////
/**
 * Determins the most significant bit set of given unsigned 64-bit value
 * \param The unsigned 64-bit value 
 * \return Most significant bit set of given unsigned 64-bit value
 */
U64 Msb64(register U64 x)
///////////////////////////////////////////////
{
  x |= (x >> 1);
  x |= (x >> 2);
  x |= (x >> 4);
  x |= (x >> 8);
  x |= (x >> 16);
  x |= (x >> 32);
  return(x & ~(x >> 1));
}

///////////////////////////////////////////////
/**
 * Determins the most significant bit set of given unsigned 32-bit value
 * \param The unsigned 32-bit value 
 * \return Most significant bit set of given unsigned 32-bit value
 */
ulong Msb32(register ulong x)
///////////////////////////////////////////////
{
  x |= (x >> 1);
  x |= (x >> 2);
  x |= (x >> 4);
  x |= (x >> 8);
  x |= (x >> 16);
  return(x & ~(x >> 1));
}

///////////////////////////////////////////////
/**
 * Determins the position of the first set bit in given unsigned 64-bit value (where bit position of given value 1 is 0)
 * \param The unsigned 64-bit value 
 * \return bit position where first bit is set
 */
ushort GetIdxB(U64 b)
///////////////////////////////////////////////
{
  return bithash64[(b*DEBRUIJN64)>>58];
}

///////////////////////////////////////////////
/**
 * Determins the position of the first set bit in given unsigned 32-bit value (where bit position of given value 1 is 0)
 * \param The unsigned 32-bit value 
 * \return bit position where first bit is set
 */
ushort GetIdxB(ulong b)
///////////////////////////////////////////////
{
  return bithash32[(b*DEBRUIJN32)>>27];
}

#ifdef _WIN32
  ///////////////////////////////////////////////
  /**
  * Determins the position of the first set bit in given unsigned 64-bit value (where bit position of given value 1 is 0) and clears this bit
  * \param Pointer to the unsigned 64-bit value 
  * \return bit position where first bit is set
  * \details This assembler function returns the first set bit position and clears the bit at this position
  */
  inline ushort ClrFirstBit(U64 *ptr2b) 
  ///////////////////////////////////////////////
  {
    __asm
    {
	    xor	edx, edx
	    mov	ebx, [ptr2b]
	    xor	eax, eax
	    inc	edx
	    bsf	ecx, [ebx]
	    jnz	found
	    bsf	ecx, [ebx+4]
	    lea	ebx, [ebx+4]
	    xor	eax, 32
    found:
	    shl	edx, cl
	    xor	eax, ecx
	    xor	[ebx], edx
    }
  }

  ///////////////////////////////////////////////
  /**
  * Determins the position of the first set bit in given unsigned 32-bit value (where bit position of given value 1 is 0) and clears this bit
  * \param Pointer to the unsigned 32-bit value 
  * \return bit position where first bit is set
  * \details This assembler function returns the first set bit position and clears the bit at this position
  */
  inline ushort ClrFirstBit(ulong *ptr2b) 
  ///////////////////////////////////////////////
  {
    __asm
    {
	    xor	edx, edx
	    mov	ebx, [ptr2b]
	    xor	eax, eax
	    inc	edx
	    bsf	ecx, [ebx]
	    jnz	found
	    bsf	ecx, [ebx+4]
	    lea	ebx, [ebx+4]
	    xor	eax, 32
    found:
	    shl	edx, cl
	    xor	eax, ecx
	    xor	[ebx], edx
    }
  }
#endif // _WIN32

size_t GroupCount64(U64 x)         { return BitCount64( (x^(x>>1)) ) / 2 + (x & 1); }
size_t GroupCount32(ulong x)       { return BitCount32( (x^(x>>1)) ) / 2 + (x & 1); }
size_t GroupCount64Least2(U64 x)   { return GroupCount64( x & ( (x<<1) & (x>>1) ) );}    
size_t GroupCount32Least2(ulong x) { return GroupCount32( x & ( (x<<1) & (x>>1) ) );}

