#pragma once

#include "types.h"

extern void InitBits();
extern ulong Lsb32(register ulong x);
extern ulong Msb32(register ulong x);
extern ushort GetIdxB(ulong b);

extern ushort GetIdxB(U64 b);
extern U64 Lsb64(register U64 x);
extern U64 Msb64(register U64 x);
extern size_t BitCount64(U64);
extern size_t GroupCount64(U64); // two adjacent bits are a group
extern size_t GroupCount64Least2(U64); // more then 2adjacent bits are a group

extern size_t BitCount32(ulong);
extern size_t GroupCount32(ulong); // two adjacent bits are a group
extern size_t GroupCount32Least2(ulong); // more then 2adjacent bits are a group

#ifdef _WIN32
  extern  ushort ClrFirstBit(U64 *ptr2b);
  extern  ushort ClrFirstBit(ulong *ptr2b);
#endif

