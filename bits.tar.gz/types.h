#pragma once

#include <time.h>
#include <stdio.h>
#include <iostream>
#include <algorithm>
#include <vector>
#include <assert.h>

typedef unsigned char uchar   ;
typedef unsigned short ushort ;
typedef unsigned long ulong   ;

#ifdef _WIN32
  typedef unsigned __int64 U64  ;
#else
  /// \todo hpj 20090218 CHECK, this might not be a 64bit-value!!
  typedef unsigned long long int U64  ;
#endif

