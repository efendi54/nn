import math

class Layer:
    def __init__(self, neurons, con):
        self.inputs = [0.0 for i in range(0, neurons)]
        self.outputs = [0.0 for i in range(0, neurons)]
        self.biases = [0.0 for i in range(0, neurons)]
        self.weights = []
        if con > 0:
            for n in range(0, neurons):
                self.weights.append([0 for w in range(0, con)])

    def sigmoid(self, x):
        return 1.0 / (1.0 + math.exp(-x))

    def feed(self, x):
        for ni in range(0, len(self.inputs)):
            self.inputs[ni] = 0
            for wi in range(0, len(self.weights[ni])):
                self.inputs[ni] += self.weights[ni][wi] * x[wi]
            self.inputs[ni] += self.biases[ni]
            self.outputs[ni] = self.sigmoid(self.inputs[ni])

class FFNet:
    def __init__(self, arch=[]):
        self.layers = []
        self.reset(arch)

    def reset(self, arch):
        self.layers = []
        for l, n in enumerate(arch):
            con = 0
            if l > 0:
                con = len(self.layers[l - 1].outputs)
            self.layers.append(Layer(n, con))

    def feed(self, x):
        self.layers[0].outputs = x
        for li in range(1, len(self.layers)):
            self.layers[li].feed(self.layers[li-1].outputs)

    def read_net(self, file_name="netw.txt"):
        with open(file_name) as file:
            arch = [int(i) for i in file.readline().split()]
            self.reset(arch)

            net_weights = []
            for line in file.readlines():
                net_weights.append([float(i) for i in line.split()])

            start = 0
            for li, l in enumerate(arch):
                if li > 0:
                    end = start+l
                    layer_weights = net_weights[start:end]

                    # caution: extract the biases first
                    biases = []
                    for weights in layer_weights:
                        biases.append(weights[0])
                        del(weights[0])

                    self.layers[li].weights = layer_weights
                    self.layers[li].biases = biases
                    start = end

