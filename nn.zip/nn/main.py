import sys
from PyQt5 import QtWidgets
from PyQt5 import QtGui
from PyQt5 import QtCore
from random import random

from net import FFNet


# ////////////////////////////////////////////
class GridCanvas(QtWidgets.QWidget):
  trigger = QtCore.pyqtSignal()

  def __init__(self, grid_height=10, grid_cnt_x=28, grid_cnt_y=28):
    super(GridCanvas, self).__init__()
    self.grid_height = grid_height
    self.grid_cnt_x = grid_cnt_x
    self.grid_cnt_y = grid_cnt_y
    self.dragging = False

    self.data = [[0 for i in range(0, self.grid_cnt_x)] for j in range(0, self.grid_cnt_y)]
    self.init_ui()

  def init_ui(self):
    ms = QtCore.QSize(self.grid_cnt_x * self.grid_height + 1,
                      self.grid_cnt_y * self.grid_height + 1)
    self.setGeometry(0, 0, ms.width(), ms.height())
    self.setMinimumSize(ms)
    self.adjustSize()

  def paintEvent(self, e):
    qp = QtGui.QPainter()
    qp.begin(self)
    self.draw_data(qp)
    qp.end()

  def mouseReleaseEvent(self, event):
    self.dragging = False

  def mousePressEvent(self, event):
    self.dragging = True

  def mouseMoveEvent(self, event):
    if not self.dragging:
      return
    point = event.pos()
    c = point.x()
    r = point.y()
    c = int(c/self.grid_height)
    r = int(r/self.grid_height)
    if (c in range(0, self.grid_cnt_y)) and (r in range(0, self.grid_cnt_x)):
      gv = 0.8 + ((random() * 0.2))
      self.data[r][c] = gv
      self.repaint()
      self.trigger.emit()

  def draw_data(self, qp):
    color = QtGui.QColor("black")
    qp.setPen(color)
    for i in range(0, self.grid_cnt_x):
      for j in range(0, self.grid_cnt_y):
        qp.drawRect(i * self.grid_height,
                    j * self.grid_height,
                    self.grid_height,
                    self.grid_height)

        data_color = QtGui.QColor("black")
        data_color.setAlpha(self.data[j][i] * 255)
        qp.fillRect(i * self.grid_height,
                    j * self.grid_height,
                    self.grid_height,
                    self.grid_height, data_color)

  def clear_data(self):
    for i in range(0, self.grid_cnt_x):
      for j in range(0, self.grid_cnt_y):
        self.data[i][j] = 0
    self.repaint()

  def set_data(self, data):
    if len(data) != (self.grid_cnt_x * self.grid_cnt_y):
      return
    for i in range(0, self.grid_cnt_x):
      for j in range(0, self.grid_cnt_y):
        idx = (i * self.grid_cnt_x) + j
        self.data[i][j] = data[idx]
    self.repaint()

# ////////////////////////////////////////////
class NetOutCanvas(QtWidgets.QFrame):
  def __init__(self):
     super(NetOutCanvas, self).__init__()
     self.box_height = 30
     self.values = [0 for i in range(0, 10)]
     self.init_ui()

  def init_ui(self):
    ms = QtCore.QSize(len(self.values) * self.box_height + 1, self.box_height + 10)
    self.setGeometry(0, 0, ms.width(), ms.height())
    self.setMinimumSize(ms)
    self.adjustSize()

  def set_values(self, values):
    self.values = values
    self.repaint()

  def reset_values(self):
    self.values = [0 for i in range(0, len(self.values))]
    self.repaint()

  def paintEvent(self, e):
    qp = QtGui.QPainter()
    qp.begin(self)
    self.draw_boxes(qp)
    qp.end()

  def draw_boxes(self, qp):
    color = QtGui.QColor("green")
    qp.setPen(color)
    mv = max(self.values)
    mv_idx = self.values.index(mv)
    for val_idx, val in enumerate(self.values):
        x_pos = val_idx * self.box_height
        y_pos = (1-val) * self.box_height
        width = self.box_height
        height = val * self.box_height
        qp.drawText(x_pos+(self.box_height/2), self.box_height+10, str(val_idx))
        if val_idx == mv_idx:
          qp.fillRect(x_pos, 0, width, height, QtGui.QColor("red"))
        qp.drawRect(x_pos, 0, width, height)


# ////////////////////////////////////////////
class MyWidget(QtWidgets.QWidget):
  def __init__(self):
    super(MyWidget, self).__init__()
    self.paint_canvas = GridCanvas()
    self.netout_canvas = NetOutCanvas()
    self.classify_button = QtWidgets.QPushButton("Classify", self)
    self.clear_button = QtWidgets.QPushButton("Clear", self)

    self.net = FFNet()
    self.net.read_net()
    data = self.read_data("testx.txt")
    self.paint_canvas.set_data(data)
    self.classify()

    self.init_ui()

  def init_ui(self):
    self.clear_button.clicked.connect(self.clear_press)
    self.classify_button.clicked.connect(self.classify)
    self.paint_canvas.trigger.connect(self.classify)

    vbl = QtWidgets.QVBoxLayout()
    vbl.setSpacing(5)
    vbl.addWidget(self.netout_canvas)
    vbl.addWidget(self.paint_canvas)
    vbl.addWidget(self.classify_button)
    vbl.addWidget(self.clear_button)
    sh = vbl.sizeHint()
    sh.setWidth(sh.width() )
    sh.setHeight(sh.height() )
    self.setLayout(vbl)
    self.resize(sh)
    self.show()

  def read_data(self, file_name):
    d = []
    with open(file_name) as file:
      d = [float(i) for i in file.readline().split()]
    return d

  def clear_press(self):
    self.paint_canvas.clear_data()
    self.classify()

  def classify(self):
    x = [item for sublist in self.paint_canvas.data for item in sublist]
    self.netout_canvas.reset_values()
    if len(x) > 0:
      self.net.feed(x)
      self.netout_canvas.set_values(self.net.layers[-1].outputs)

def main():
  app = QtWidgets.QApplication(sys.argv)
  ex = MyWidget()
  sys.exit(app.exec_())

if __name__ == "__main__":
  main()

