exe is build via cxfreeze tool (a setup.py must be present):
python setup.py build
