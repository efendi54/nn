from PyQt5 import QtCore, QtGui


# //////////////////////////////////////////////////
class GameInfoModel(QtCore.QAbstractTableModel):
    def __init__(self, parent=None):
        QtCore.QAbstractTableModel.__init__(self, parent)
        self.data = []
        self.data_colors = None

    # --------------------------------
    def rowCount(self, parent):
        return len(self.data)

    # --------------------------------
    def columnCount(self, parent):
        if self.data:
            return 2 # len(self.data[0])
        return 0

    # --------------------------------
    def reset_game_info(self):
        self.beginResetModel()
        del self.data[:]
        del self.data_colors
        self.data = []
        self.data_colors = None
        self.endResetModel()

    # --------------------------------
    def set_game_info_colors(self, game_info_colors=None):
        if game_info_colors:
            self.data_colors = game_info_colors

    # --------------------------------
    def set_game_info(self, game_info):
        self.layoutAboutToBeChanged.emit()
        self.reset_game_info()
        self.beginInsertRows(QtCore.QModelIndex(), len(self.data), len(self.data))
        for d in game_info:
            self.data += [d]
        self.endInsertRows()
        self.layoutChanged.emit()

    # --------------------------------
    def data(self, index, role):
        if not index.isValid():
            return QtCore.QVariant()
        elif role == QtCore.Qt.TextAlignmentRole:
            return QtCore.Qt.AlignLeft
        elif role == QtCore.Qt.BackgroundRole:
            if self.data_colors:
                key = self.data[index.row()][0]
                if key in self.data_colors:
                    return self.data_colors[key]
            return QtGui.QBrush(QtCore.Qt.lightGray)
        elif role != QtCore.Qt.DisplayRole:
            return QtCore.QVariant()
        # CAUTION: data is holding game-info cathegory in column-0 for each row
        return QtCore.QVariant(self.data[index.row()][index.column()+1])

