from cx_Freeze import setup, Executable

import glob, os
import sys

# Dependencies are automatically detected, but it might need
# fine tuning.

additional_files = ['main.ui','..\..\game_spec.py','..\..\example_specs\example_spec.json','..\..\pylog.conf']
pngs = []

for file in os.listdir("."):
  if file.endswith(".png"):
    additional_files.append(file)
    
buildOptions = dict(
  packages=[],
  excludes=[],
  include_files=additional_files)

base = 'Win32GUI' if sys.platform=='win32' else None

executables = [
    Executable('main.py', base=base,icon="slot32.ico")
]

setup(name='GameSpecViewer',
      version = '2.1',
      description = 'game-spec viewer',
      options = dict(build_exe = buildOptions),
      executables = executables, requires=['PyQt5','json'])
