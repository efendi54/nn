import numpy as np
import random
import functions


class QuadraticCost(object):

    @staticmethod
    def fn(a, y):
        """Return the cost associated with an output ``a`` and desired output
        ``y``.
        """
        return 0.5*np.linalg.norm(a-y)**2

    @staticmethod
    def delta(z, a, y, transfer=functions.Sigmoid()):
        """Return the error delta from the output layer."""
        return -(y-a) * transfer.d_func(z)


class CrossEntropyCost(object):

    @staticmethod
    def fn(a, y):
        """Return the cost associated with an output ``a`` and desired output
        ``y``.  Note that np.nan_to_num is used to ensure numerical
        stability.  In particular, if both ``a`` and ``y`` have a 1.0
        in the same slot, then the expression (1-y)*np.log(1-a)
        returns nan.  The np.nan_to_num ensures that that is converted
        to the correct value (0.0).
        """
        return np.sum(np.nan_to_num(-y*np.log(a)-(1-y)*np.log(1-a)))

    @staticmethod
    def delta(z, a, y, transfer):
        """Return the error delta from the output layer.  Note that the
        parameter ``z`` is not used by the method.  It is included in
        the method's parameters in order to make the interface
        consistent with the delta method for other cost classes.
        """
        return -(y-a)


class Net:
    def __init__(self, layer_sizes=[], cost=QuadraticCost, transfer_func=functions.Sigmoid()):
        self.transfer = transfer_func
        self.layer_sizes = layer_sizes
        self.biases = [np.random.randn(y, 1) for y in self.layer_sizes[1:]]
        self.weights = [np.random.randn(y, x) / np.sqrt(x)
                        for x, y in zip(self.layer_sizes[:-1], self.layer_sizes[1:])]
        self.cost = cost

    def weights_fixed(self, fixed_weight=0.1):
        self.weights = []
        self.biases = []
        for x, y in zip(self.layer_sizes[:-1], self.layer_sizes[1:]):
            self.weights.append(np.array([[fixed_weight for r in range(x)] for c in range(y)]))
            b = np.array([fixed_weight] * y)
            b = b.reshape(b.shape[0], 1)
            self.biases.append(b)

    def weights_gaussian(self):
        self.biases = [np.random.randn(y, 1) for y in self.layer_sizes[1:]]
        self.weights = [np.random.randn(y, x)
                        for x, y in zip(self.layer_sizes[:-1], self.layer_sizes[1:])]

    def feed(self, x):
        all_nets = [x]
        all_outs = [x]
        for b, w in zip(self.biases, self.weights):
            net = np.dot(w, x)
            net += b
            x = self.transfer.func(net)
            all_nets.append(net)
            all_outs.append(x)
        return all_nets, all_outs

    def back_prop(self, x, y):
        # feed in first
        all_nets, all_outs = self.feed(x)

        d_weights = [[] for w in self.weights]
        d_biases = [[] for b in self.biases]

        # calc ej = -(dEx / dnetj) for output layers
        #ej = -(y - all_outs[-1])
        #ej *= self.transfer.d_func(all_nets[-1])
        ej = self.cost.delta(all_nets[-1], all_outs[-1], y, self.transfer)

        # calc delta_w = (dEx / dnetj) xji
        x = all_outs[-2]
        d_weights[-1] = np.dot(ej, x.transpose())
        d_biases[-1] = ej

        # ej and delta_w for hidden layers
        for h in range(2, len(self.layer_sizes)):
            sp = self.transfer.d_func(all_nets[-h])
            w = self.weights[-h + 1].transpose()
            wdk = np.dot(w, ej)
            ej = sp * wdk
            x = all_outs[-h - 1]
            d_weights[-h] = np.dot(ej, x.transpose())
            d_biases[-h] = ej

        return d_weights, d_biases

    def test(self, test_data):
        test_results = [(np.argmax(self.feed(x)[1][-1]), y)
                        for (x, y) in test_data]
        return sum(int(x == np.argmax(y)) for (x, y) in test_results)

    @staticmethod
    def __convert_to_tanh_range(y):
        return np.array([[-1] if e == [0] else e for e in y.tolist()])

    def sgd(self, training_data, shuffle=False, epochs=10, mini_batch_size=1, eta=3.0, test_data=None):

        # in case of tanh as transfer function convert target outputs into range [-1,1] ..
        if isinstance(self.transfer, functions.Tanh):
            for i, (x, y) in enumerate(training_data):
                training_data[i] = (x, self.__convert_to_tanh_range(y))
            for i, (x, y) in enumerate(test_data):
                test_data[i] = (x, self.__convert_to_tanh_range(y))

        if test_data:
            n_test = len(test_data)
        n = len(training_data)
        for j in range(epochs):
            if shuffle:
                random.shuffle(training_data)
            mini_batches = [
                training_data[k:k + mini_batch_size]
                for k in range(0, n, mini_batch_size)]
            for mini_batch in mini_batches:
                self.update_mini_batch(mini_batch=mini_batch, eta=eta, lmbda=0.5, n=len(training_data))
            if test_data:
                g = self.test(test_data)
                print("Epoch {0}: {1} / {2}".format(
                    j, g, n_test))
            else:
                print("Epoch {0} complete".format(j))

    '''
    def update_mini_batch(self, mini_batch, eta):
        nabla_b = [np.zeros(b.shape) for b in self.biases]
        nabla_w = [np.zeros(w.shape) for w in self.weights]
        for x, y in mini_batch:
            delta_nabla_w, delta_nabla_b = self.back_prop(x, y)
            nabla_b = [nb + dnb for nb, dnb in zip(nabla_b, delta_nabla_b)]
            nabla_w = [nw + dnw for nw, dnw in zip(nabla_w, delta_nabla_w)]
        self.weights = [w - (eta / len(mini_batch)) * nw
                        for w, nw in zip(self.weights, nabla_w)]
        self.biases = [b - (eta / len(mini_batch)) * nb
                       for b, nb in zip(self.biases, nabla_b)]
    '''
    def update_mini_batch(self, mini_batch, eta, lmbda, n):
        nabla_b = [np.zeros(b.shape) for b in self.biases]
        nabla_w = [np.zeros(w.shape) for w in self.weights]
        for x, y in mini_batch:
            delta_nabla_w, delta_nabla_b = self.back_prop(x, y)
            nabla_b = [nb + dnb for nb, dnb in zip(nabla_b, delta_nabla_b)]
            nabla_w = [nw + dnw for nw, dnw in zip(nabla_w, delta_nabla_w)]
        self.weights = [(1 - eta * (lmbda / n)) * w - (eta / len(mini_batch)) * nw
                        for w, nw in zip(self.weights, nabla_w)]
        self.biases = [b - (eta / len(mini_batch)) * nb
                       for b, nb in zip(self.biases, nabla_b)]
