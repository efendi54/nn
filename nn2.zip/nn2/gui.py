import numpy as np
import pickle
from PyQt5 import QtWidgets, QtGui, QtCore, uic
from random import random


def min_max_scale(xdata):
    for xi, x in enumerate(xdata):
        xdata[xi] = (x - min(x)) / (max(x) - min(x))
    return xdata


class GridCanvas(QtWidgets.QWidget):
    trigger = QtCore.pyqtSignal()

    def __init__(self, grid_height=10, grid_cnt_x=28, grid_cnt_y=28):
        super(GridCanvas, self).__init__()
        # create ui ..
        self.ui = uic.loadUi("grid_canvas.ui", self)

        self.grid_height = grid_height
        self.grid_cnt_x = grid_cnt_x
        self.grid_cnt_y = grid_cnt_y
        self.dragging = False

        self.data = [[0 for i in range(0, self.grid_cnt_x)] for j in range(0, self.grid_cnt_y)]
        self.init_ui()

    def init_ui(self):
        ms = QtCore.QSize(self.grid_cnt_x * self.grid_height + 1,
                          self.grid_cnt_y * self.grid_height + 1)
        self.setGeometry(0, 0, ms.width(), ms.height())
        self.setMinimumSize(ms)
        self.adjustSize()

    def paintEvent(self, e):
        qp = QtGui.QPainter()
        qp.begin(self)
        self.draw_data(qp)
        qp.end()

    def mouseReleaseEvent(self, event):
        self.dragging = False

    def mousePressEvent(self, event):
        self.dragging = True

    def mouseMoveEvent(self, event):
        if not self.dragging:
            return
        point = event.pos()
        c = point.x()
        r = point.y()
        c = int(c / self.grid_height)
        r = int(r / self.grid_height)
        if (c in range(0, self.grid_cnt_y)) and (r in range(0, self.grid_cnt_x)):
            gv = 0.8 + (random() * 0.2)
            self.data[r][c] = gv
            self.repaint()
            self.trigger.emit()

    def draw_data(self, qp):
        color = QtGui.QColor("black")
        qp.setPen(color)
        for i in range(0, self.grid_cnt_x):
            for j in range(0, self.grid_cnt_y):
                qp.drawRect(i * self.grid_height,
                            j * self.grid_height,
                            self.grid_height,
                            self.grid_height)

                data_color = QtGui.QColor("black")
                data_color.setAlpha((self.data[j][i]>0) * 255)
                qp.fillRect(i * self.grid_height,
                            j * self.grid_height,
                            self.grid_height,
                            self.grid_height, data_color)

    def clear_data(self):
        for i in range(0, self.grid_cnt_x):
            for j in range(0, self.grid_cnt_y):
                self.data[i][j] = 0
        self.repaint()

    def set_data(self, data):
        if len(data) != (self.grid_cnt_x * self.grid_cnt_y):
            return
        for i in range(0, self.grid_cnt_x):
            for j in range(0, self.grid_cnt_y):
                idx = (i * self.grid_cnt_x) + j
                self.data[i][j] = data[idx]
        self.repaint()


# ////////////////////////////////////////////
class NetOutCanvas(QtWidgets.QFrame):
    def __init__(self):
            super(NetOutCanvas, self).__init__()
            self.box_height = 30
            self.values = [0 for i in range(0, 10)]
            self.init_ui()

    def init_ui(self):
        ms = QtCore.QSize(len(self.values) * self.box_height + 1, self.box_height + 10)
        self.setGeometry(0, 0, ms.width(), ms.height())
        self.setMinimumSize(ms)
        self.adjustSize()

    def set_values(self, values):
        self.values = values
        self.repaint()

    def reset_values(self):
        self.values = [0 for i in range(0, len(self.values))]
        self.repaint()

    def paintEvent(self, e):
        qp = QtGui.QPainter()
        qp.begin(self)
        self.draw_boxes(qp)
        qp.end()

    def draw_boxes(self, qp):
        color = QtGui.QColor("green")
        qp.setPen(color)
        mv = max(self.values)
        mv_idx = self.values.index(mv)
        for val_idx, val in enumerate(self.values):
            x_pos = val_idx * self.box_height
            width = self.box_height
            height = val * self.box_height
            qp.drawText(x_pos + (self.box_height / 2), self.box_height + 10, str(val_idx))
            if val_idx == mv_idx:
                qp.fillRect(x_pos, 0, width, height, QtGui.QColor("red"))
            qp.drawRect(x_pos, 0, width, height)


# ///////////////////////////////
class MainWidget(QtWidgets.QWidget):
    def __init__(self, net, parent=None):
        super(MainWidget, self).__init__()

        self.all_data = []
        self.data_idx = 0
        self.net = net

        # create ui ..
        self.ui = uic.loadUi("main_widget.ui", self)

        self.next_data_button = QtWidgets.QPushButton("Next", self)
        self.prev_data_button = QtWidgets.QPushButton("Previous", self)
        self.clear_button = QtWidgets.QPushButton("Clear", self)
        self.load_net = QtWidgets.QPushButton("Open Net", self)
        self.paint_canvas = GridCanvas()
        self.netout_canvas = NetOutCanvas()

        self.init_ui()

    def init_ui(self):
        self.clear_button.clicked.connect(self.clear_press)
        self.next_data_button.clicked.connect(lambda: self.next_data(1))
        self.prev_data_button.clicked.connect(lambda: self.next_data(-1))
        self.load_net.clicked.connect(self.load_net_weights)
        self.paint_canvas.trigger.connect(self.classify)

        shortcut = QtWidgets.QShortcut(QtGui.QKeySequence("Ctrl+O"), self)
        shortcut.activated.connect(self.load_net_weights)

        npwdgt = QtWidgets.QWidget(self)
        hbl = QtWidgets.QHBoxLayout()
        hbl.setSpacing(5)
        hbl.addWidget(self.prev_data_button)
        hbl.addWidget(self.next_data_button)
        npwdgt.setLayout(hbl)

        vbl = QtWidgets.QVBoxLayout()
        vbl.setSpacing(5)
        vbl.addWidget(self.load_net)
        vbl.addWidget(self.netout_canvas)
        vbl.addWidget(self.paint_canvas)
        vbl.addWidget(npwdgt)
        vbl.addWidget(self.clear_button)
        sh = vbl.sizeHint()
        sh.setWidth(sh.width())
        sh.setHeight(sh.height())
        self.setLayout(vbl)
        self.resize(sh)
        self.show()

    def set_data(self, all_data):
        self.all_data = all_data

    def next_data(self, step=1):
        if len(self.all_data) == 0:
            pass
        self.data_idx = (self.data_idx + step) % len(self.all_data)
        data = self.all_data[self.data_idx]
        self.paint_canvas.set_data(data.tolist())
        self.classify()

    def clear_press(self):
        self.paint_canvas.clear_data()
        self.netout_canvas.reset_values()

    def load_net_weights(self):
        fname = QtWidgets.QFileDialog.getOpenFileName(self, 'Load Weights', '.', 'Mnist Net Weights (*.pkl)')
        if not fname[0]:
            return
        # import weights from pickle file
        with open(fname[0], "rb") as f:
            (weights, biases) = pickle.load(f)
            self.net.weights = weights
            self.net.biases = biases

    def classify(self):
        x = [item for sublist in self.paint_canvas.data for item in sublist]
        self.netout_canvas.reset_values()
        if len(x) > 0:
            npd = np.array(x, dtype=np.float64).reshape(len(x), 1)
            # min-max-scale ..
            npd -= npd.min()
            npd /= npd.ptp()
            n, o = self.net.feed(npd)
            acts = o[-1].tolist()
            acts = [item for sublist in acts for item in sublist]
            self.netout_canvas.set_values(acts)


'''
import sys
from PyQt5 import QtGui, QtWidgets

from matplotlib.backends.backend_qt4agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt4agg import NavigationToolbar2QT as NavigationToolbar
from matplotlib.figure import Figure

import random


class Window(QtWidgets.QDialog):
    def __init__(self, parent=None):
        super(Window, self).__init__(parent)

        # a figure instance to plot on
        self.figure = Figure()

        # this is the Canvas Widget that displays the `figure`
        # it takes the `figure` instance as a parameter to __init__
        self.canvas = FigureCanvas(self.figure)

        # this is the Navigation widget
        # it takes the Canvas widget and a parent
        self.toolbar = NavigationToolbar(self.canvas, self)

        # Just some button connected to `plot` method
        self.button = QtWidgets.QPushButton('Plot')
        self.button.clicked.connect(self.plot)

        # set the layout
        layout = QtWidgets.QVBoxLayout()
        layout.addWidget(self.toolbar)
        layout.addWidget(self.canvas)
        layout.addWidget(self.button)
        self.setLayout(layout)

    def plot(self):
        # plot some random stuff random data
        data = [random.random() for i in range(10)]

        # create an axis
        ax = self.figure.add_subplot(111)

        # discards the old graph
        ax.clear()

        # plot data
        ax.plot(data, '*-')

        # refresh canvas
        self.canvas.draw()

if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)

    main = Window()
    main.show()

    sys.exit(app.exec_())
'''
