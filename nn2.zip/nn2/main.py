import numpy as np
import pickle
import gzip
import sys
from gui import MainWidget
from PyQt5 import QtWidgets, QtGui, QtCore, uic
import net
import functions

'''
def de_bruijn(k, n):
    """
    de Bruijn sequence for alphabet k
    and subsequences of length n.
    """
    try:
        # let's see if k can be cast to an integer;
        # if so, make our alphabet a list
        _ = int(k)
        alphabet = list(map(str, range(k)))

    except (ValueError, TypeError):
        alphabet = k
        k = len(k)

    a = [0] * k * n
    sequence = []

    def db(t, p):
        if t > n:
            if n % p == 0:
                sequence.extend(a[1:p + 1])
        else:
            a[t] = a[t - p]
            db(t + 1, p)
            for j in range(a[t - p] + 1, k):
                a[t] = j
                db(t + 1, t)
    db(1, 1)
    return "".join(alphabet[i] for i in sequence)

'''

def read_mnist_data():
    # read in data from zipped pickle files ..
    with gzip.open('datasets/mnist/mnist_train_data_xy_minmax_scaled.pkl.gz', 'rb') as f:
        (train_data_x, train_data_y) = pickle.load(f)
    with gzip.open('datasets/mnist/mnist_test_data_xy_minmax_scaled.pkl.gz', 'rb') as f:
        (test_data_x, test_data_y) = pickle.load(f)
    return train_data_x, train_data_y, test_data_x, test_data_y


def main():
    #print(de_bruijn(2, 6))

    # get data ...
    train_data_x, train_data_y, test_data_x, test_data_y = read_mnist_data()
    train_data = [(x.reshape(-1, 1),
                  np.array(y).reshape(-1, 1)) for x, y in zip(train_data_x, train_data_y)]
    test_data = [(x.reshape(-1, 1),
                 np.array(y).reshape(-1, 1)) for x, y in zip(test_data_x, test_data_y)]

    nn = net.Net(layer_sizes=[784, 100, 10], cost=net.QuadraticCost)
    nn.sgd(train_data, shuffle=True, epochs=10, mini_batch_size=30, eta=4.0, test_data=test_data)

    # import weights from pickle file
    #with open("weights.pkl", "rb") as f:
    #    nn = pickle.load(f)

    # export weights to pickle file ..
    with open("weights.pkl", "wb") as f:
        pickle.dump(nn, f)

    app = QtWidgets.QApplication(sys.argv)
    app.setStyle("plastique")

    mw = MainWidget(nn)
    mw.set_data(train_data_x)
    mw.show()

    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
