import numpy as np


class Function(object):
    def __init__(self):
        pass

    def func(self, x):
        return x

    def d_func(self, x):
        return 1


class Sigmoid(Function):
    def __init__(self):
        pass

    def func(self, x):
        return 1.0 / (1.0 + np.exp(-x))

    def d_func(self, x):
        return self.func(x) * (1 - self.func(x))


class Tanh(Function):
    def __init__(self):
        pass

    def func(self, x):
        return np.tanh(x)

    def d_func(self, x):
        return 1 - self.func(x)**2

