#!/usr/bin/env python

import sys
import argparse
import json


class GameSpec(object):
    # -----------------------------
    def __init__(self, spec_file_name):
        json_file = open(spec_file_name)
        d = json.load(json_file)
        gs = d["game_spec"]
        self.code_comment = "/*\n CAUTION: GENERATED SOURCE CODE. " \
                            "DO NOT MODIFY BY HAND.\n {:s} \n GAME-SPEC-VERSION: {:s}\n/*".format(gs["name"],
                                                                                                  gs["version"])
        self.reels = gs["reels"]

    def get_reel_symbol_enum(self):
        # extract/generate symbol-enums ..
        symbol_enums = self.reels["symbol_enum"]
        sym_list = symbol_enums.split(",")
        return sym_list

    def get_reel_sets(self):
        # extract/generate symbol-enums ..
        reel_sets = self.reels["reel_sets"]
        return reel_sets

# -----------------------------
def main(argv):
    args_to_parse = argv[1:]
    parser = argparse.ArgumentParser(description='Tool to generate cpp-code from provided game-spec-file.',
                                     usage=argv[0] + '--spec <SPEC_FILE> [OPTIONS]')

    required_params = parser.add_argument_group("required parameters")
    required_params.add_argument('--spec',
                                 default=None,
                                 help="Specifies name of (json) game-specification file to be used for code generation",
                                 dest='spec',
                                 required=True)

    cmd_line_args = parser.parse_args(args_to_parse)

    try:
        gs = GameSpec(cmd_line_args.spec)
        symbols = gs.get_reel_symbol_enum()
    except IOError as e:
        print("Unable to open file:"+e)  # Does not exist OR no read permissions

# -----------------------------
if __name__ == '__main__':
    main(sys.argv)
