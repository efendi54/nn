import random
from collections import Counter
from enum import Enum


class Win:
    def __init__(self, points=0, giga_spins=0, free_games=0):
        self.points = points
        self.giga_spins = giga_spins
        self.free_games = free_games

    def print(self):
        print((self.points, self.giga_spins, self.free_games))


class LineWin:
    def __init__(self, line_arrangement, win):
        self.win_line = line_arrangement
        self.win = win

    def print(self):
        print(self.win_line)
        self.win.print()


class Stripes:
    def __init__(self, stripes, window_sizes, win_lines):
        self.stripes = []
        self.stripe_window_sizes = []
        self.win_lines = []
        self.set_stripes(stripes, window_sizes, win_lines)

    def set_stripes(self, stripes, window_sizes, win_lines):
        if self.validate(stripes, window_sizes, win_lines):
            self.stripes = stripes
            self.stripe_window_sizes = window_sizes
            self.win_lines = win_lines

    def get_stripe_amount(self):
        return len(self.stripes)

    def get_stripe_len(self, idx):
        return len(self.stripes[idx])

    def print(self):
        print(self.stripes)
        print(self.stripe_window_sizes)
        print(self.win_lines)
        print("")

    @staticmethod
    def validate(stripes, window_sizes, win_lines):
        # ---------------------------------
        # validate stripes against window-sizes ..
        # ---------------------------------
        if len(stripes) != len(window_sizes):
            raise RuntimeError("amount of stripes must match amount of window-sizes")
        # each window-size w_i has to be < than stripe length of s_i
        for widx, ws in enumerate(window_sizes):
            sl = len(stripes[widx])
            if sl <= ws:
                raise RuntimeError("each window_size has to be smaller than stripe-size")

        # ---------------------------------
        # validate window-sizes against win-lines ..
        # ---------------------------------
        # each winline should contain at most len(stripes) elements
        for line in win_lines:
            if len(line) != len(stripes):
                raise RuntimeError("elements of winline must be equal to amount of stripes")
        return True

    def get_window_and_lines(self, positions=[]):
        window = []
        lines_content = []

        if not positions:
            positions = [0] * self.get_stripe_amount()

        # rotate stripes and retrieve symbols in window
        for p_idx, p in enumerate(positions):
            a = p % self.get_stripe_len(p_idx)
            stripes = self.stripes[p_idx][-a:] + self.stripes[p_idx][:-a]
            window += [stripes[:self.stripe_window_sizes[p_idx]]]
        
        # retrieve symbols on each winline
        for line in self.win_lines:
            tmp = tuple()
            for p_idx, pos in enumerate(line):
                tmp += (window[p_idx][pos],)
            lines_content += [(tmp, tuple(line))]
        return window, lines_content


class Reels:
    def __init__(self):
        self.stripe_set = dict()
        self.current_stripe_key = str()
        self.positions = []

    def change_current_stripe_key(self, key):
        if key not in self.stripe_set:
            raise RuntimeError("unknown stripe-set-key:"+key)
        self.current_stripe_key = key

    def get_window_and_lines(self):
        return self.stripe_set[self.current_stripe_key].get_window_and_lines(self.positions)

    def add_stripes(self, key, stripes):
        self.stripe_set[key] = stripes

    def print(self):
        for k, v in self.stripe_set.items():
            print(k+" : ")
            v.print()
        print(self.positions)

    def spin(self):
        stripes = self.stripe_set[self.current_stripe_key]
        sa = stripes.get_stripe_amount()
        self.positions = [0] * sa
        for s in range(sa):
            r = stripes.get_stripe_len(s) - 1
            self.positions[s] = random.randint(0, r)


class WinTable:
    def __init__(self):
        self.line_wins = dict()
        self.scatter_wins = dict()

    def add_line_win(self, stake, sym_comb, win, func=None):
        self.line_wins[(stake, sym_comb)] = (sym_comb, win)

    def add_scatter_win(self, stake, sym_comb, win, func=None):
        self.scatter_wins[(stake, sym_comb)] = (sym_comb, win)

    def get_line_win(self, stake, sym_comb):
        if (stake, sym_comb) in self.line_wins:
            return self.line_wins[(stake, sym_comb)]
        return None

    def get_scatter_win(self, stake, sym_comb):
        if (stake, sym_comb) in self.scatter_wins:
            return self.scatter_wins[(stake, sym_comb)]
        return None


class ReelEvaluator:
    def __init__(self):
        self.total_win = 0
        self.reels_window = []
        self.wins = []
        self.stat = dict()

    def __calc_line_wins(self, stake, win_table):
        win_lines = []
        # usual win-line evaluation
        for idx, (line, line_arrangement) in enumerate(self.wins):
            while line:
                w = win_table.get_line_win(stake, line)
                if w:
                    win_lines += [LineWin(line_arrangement, w)]
                    break
                line = line[:-1]
        return win_lines

    def calculate_win(self, stake, reels, win_table):
        self.total_win = 0
        self.reels_window, self.wins = \
            reels.get_window_and_lines()

        # all_wins = []
        # scatter-evaluation (flattening the reel-window first ..)
        # flat = [item for sublist in self.reels_window for item in sublist]
        # sym_cnt = Counter(flat)
        # for s in win_table.scatter_wins:
        #    print(s)

        wins = self.__calc_line_wins(stake, win_table)
        if wins:
            print(wins)
            print(self.reels_window)
            x = 0

        # for win in all_wins:
        #    sym_comb = win[0]
        #    money_won = win[1]
        #    func = win[2]
        #    if sym_comb not in self.stat:
        #        self.stat[sym_comb] = 0
        #    self.stat[sym_comb] += 1
        #    self.total_win += money_won
        #    if func:
        #        func(sym_comb, self.reels_window)
