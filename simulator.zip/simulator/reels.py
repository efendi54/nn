import random


class Reels:
    def __init__(self):
        self.stripe_set = dict()
        self.current_stripe_key = str()
        self.positions = []

    # ---------------------------------
    # validate window-sizes against win-lines ..
    # ---------------------------------
    def lines_ok(self, win_lines):
        for key, (stripes, window_sizes) in self.stripe_set.items():
            # each winline should contain at most len(stripes) elements
            for line in win_lines:
                if len(line) != len(stripes):
                    raise RuntimeError("elements of winline must be equal to amount of stripes")
                    return False
        return True

    def change_current_reels_key(self, key):
        if key not in self.stripe_set:
            raise RuntimeError("unknown reel-set-key:"+key)
        self.current_stripe_key = key

    def get_window_and_lines(self, lines=None, positions=[]):
        window = []
        lines_content = []

        if not positions:
            positions = self.positions

        current_stripes = self.stripe_set[self.current_stripe_key][0]
        current_window = self.stripe_set[self.current_stripe_key][1]

        # rotate stripes and retrieve symbols in window
        for p_idx, p in enumerate(positions):
            a = p % len(current_stripes[p_idx])
            stripes = current_stripes[p_idx][a:] + current_stripes[p_idx][:a]
            window += [stripes[:current_window[p_idx]]]

        if lines:
            # retrieve symbols on each winline
            for line in lines:
                tmp = tuple()
                for p_idx, pos in enumerate(line):
                    tmp += (window[p_idx][pos],)
                lines_content += [(tmp, tuple(line))]

        return window, lines_content

    # -----------------------------
    # validate stripes against window-sizes ..
    # -----------------------------
    def add_reels(self, key, stripes, windows):
        stripes_ok = len(stripes) == len(windows)
        if not stripes_ok:
            raise RuntimeError("amount of stripes must match amount of window-sizes")
        else:
            # each window-size w_i has to be < than stripe length of s_i
            for widx, ws in enumerate(windows):
                sl = len(stripes[widx])
                stripes_ok &= (sl > ws)
                if not stripes_ok:
                    raise RuntimeError("each window_size has to be smaller than stripe-size")
                    break
        if stripes_ok:
            self.stripe_set[key] = (stripes, windows)

    def print(self):
        for k, v in self.stripe_set.items():
            print(k+" : ")
            v.print()
        print(self.positions)

    def spin(self):
        stripes = self.stripe_set[self.current_stripe_key][0]
        sa = len(stripes)
        self.positions = [0] * sa
        for s in range(sa):
            r = len(stripes[s]) - 1
            self.positions[s] = random.randint(0, r)
