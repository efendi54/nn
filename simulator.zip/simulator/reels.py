import random


class Stripes:
    def __init__(self, stripes, window_sizes, win_lines):
        self.stripes = []
        self.stripe_window_sizes = []
        self.win_lines = []
        self.set_stripes(stripes, window_sizes, win_lines)

    def set_stripes(self, stripes, window_sizes, win_lines):
        if self.validate(stripes, window_sizes, win_lines):
            self.stripes = stripes
            self.stripe_window_sizes = window_sizes
            self.win_lines = win_lines

    def get_stripe_amount(self):
        return len(self.stripes)

    def get_stripe_len(self, idx):
        return len(self.stripes[idx])

    def print(self):
        print(self.stripes)
        print(self.stripe_window_sizes)
        print(self.win_lines)
        print("")

    @staticmethod
    def validate(stripes, window_sizes, win_lines):
        # ---------------------------------
        # validate stripes against window-sizes ..
        # ---------------------------------
        if len(stripes) != len(window_sizes):
            raise RuntimeError("amount of stripes must match amount of window-sizes")
        # each window-size w_i has to be < than stripe length of s_i
        for widx, ws in enumerate(window_sizes):
            sl = len(stripes[widx])
            if sl <= ws:
                raise RuntimeError("each window_size has to be smaller than stripe-size")

        # ---------------------------------
        # validate window-sizes against win-lines ..
        # ---------------------------------
        # each winline should contain at most len(stripes) elements
        for line in win_lines:
            if len(line) != len(stripes):
                raise RuntimeError("elements of winline must be equal to amount of stripes")
        return True

    def get_window_and_lines(self, positions=[]):
        window = []
        lines = []
        if not positions:
            positions = [0] * self.get_stripe_amount()

        for pidx, p in enumerate(positions):
            a = p % self.get_stripe_len(pidx)
            stripes = self.stripes[pidx][-a:] + self.stripes[pidx][:-a]
            window += [stripes[:self.stripe_window_sizes[pidx]]]

        for line in self.win_lines:
            tmp = tuple()
            for pidx, pos in enumerate(line):
                tmp += (window[pidx][pos],)
            lines += [tmp]
        return window, lines


class Reels:
    def __init__(self):
        self.stripe_set = dict()
        self.current_stripe_key = str()
        self.positions = []

    def change_current_stripe_key(self, key):
        if key not in self.stripe_set:
            raise RuntimeError("unknown stripe-set-key:"+key)
        self.current_stripe_key = key

    def get_current_stripes(self):
        return self.stripe_set[self.current_stripe_key]

    def add_stripes(self, key, stripes):
        self.stripe_set[key] = stripes

    def print(self):
        for k, v in self.stripe_set.items():
            print(k+" : ")
            v.print()
        print(self.positions)

    def spin(self):
        stripes = self.stripe_set[self.current_stripe_key]
        sa = stripes.get_stripe_amount()
        self.positions = [0] * sa
        for s in range(sa):
            r = stripes.get_stripe_len(s) - 1
            self.positions[s] = random.randint(0, r)


class WinMatrix:
    def __init__(self):
        self.symbol_wins = dict()

    def add_symbol_win(self, stake, sym_comb, win, func=None):
        self.symbol_wins[(stake, sym_comb)] = (sym_comb, win, func)

    def get_win(self, stake, sym_comb):
        if (stake, sym_comb) in self.symbol_wins:
            return self.symbol_wins[(stake, sym_comb)]
        return None


class ReelEvaluator:
    def __init__(self):
        self.total_win = 0
        self.reels_window = []
        self.win_lines = []
        self.stat = dict()

    def calculate_win(self, stake, reels, win_matrix):
        self.total_win = 0
        self.reels_window, self.win_lines = \
            reels.get_current_stripes().get_window_and_lines(reels.positions)

        line_wins = []
        for line in self.win_lines:
            while line:
                w = win_matrix.get_win(stake, line)
                if w:
                    line_wins += [w]
                line = line[:-1]

        for win in line_wins:
            sym_comb = win[0]
            money_won = win[1]
            func = win[2]
            if sym_comb not in self.stat:
                self.stat[sym_comb] = 0
            self.stat[sym_comb] += 1
            self.total_win += money_won
            if func:
                func(sym_comb)
