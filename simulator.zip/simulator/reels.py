import random


class Reels:
    def __init__(self):
        self.stripes = []
        self.positions = []

    def inject_stripes(self):
        self.stripes = [[1, 2, 3, 2, 5], [5, 4, 3, 2, 1], [5, 1, 3, 4, 2]]
        self.positions = [0 for s in self.stripes[0]]

    def spin(self):
        for s in range(len(self.stripes)):
            self.positions[s] = random.randint(0, len(self.stripes[0])-1)
        x = 0

    def get_lines(self):
        line = tuple()
        for s in range(len(self.stripes)):
            line += (self.stripes[s][self.positions[s]],)
        return [line]