
class Simulator:
    def __init__(self):
        self.iterations = 1

    def simulate(self, game):
        for i in range(self.iterations):
            game.play_game()
        game.print_stats()
