from reels import Reels
from win import Win
from win_table import SlotWinTable, WinType
from win_evaluator import ReelLineEvaluator, ReelScatterEvaluator
from game import SlotGame


def inject_spec(reels, win_table, line_evaluator):
    reels.add_reels("base",
                    [['X', 'K', 'T', '6', 'B'],
                     ['X', 'A', 'K', '6', 'T'],
                     ['X', 'A', 'T', 'A', 'K'],
                     ['T', 'K', 'K', 'A', 'B'],
                     ['A', 'K', 'X', 'B', 'K']],
                    [3, 3, 3, 3, 3])

    reels.add_reels("free",
                    [['X', 'K', 'T', '6', 'B'],
                     ['X', 'A', 'K', '6', 'T'],
                     ['6', 'A', 'T', 'A', 'K'],
                     ['T', 'K', 'K', 'A', 'B'],
                     ['A', 'K', '6', 'X', 'K']],
                    [3, 3, 3, 3, 3])

    stake = 100
    win_table.add_win(stake, WinType.LINE_WIN, tuple('A') * 2, Win(30))
    win_table.add_win(stake, WinType.LINE_WIN, tuple('A') * 3, Win(80))
    win_table.add_win(stake, WinType.LINE_WIN, tuple('A') * 4, Win(1500))
    win_table.add_win(stake, WinType.LINE_WIN, tuple('A') * 5, Win(1260))

    win_table.add_win(stake, WinType.LINE_WIN, tuple('K') * 2, Win(10))
    win_table.add_win(stake, WinType.LINE_WIN, tuple('K') * 3, Win(400))
    win_table.add_win(stake, WinType.LINE_WIN, tuple('K') * 4, Win(1300))
    win_table.add_win(stake, WinType.LINE_WIN, tuple('K') * 5, Win(4000))

    win_table.add_win(stake, WinType.SCATTER_WIN, tuple('X'), Win(40, 0, 10))
    win_table.add_win(stake, WinType.SCATTER_WIN, tuple('X')*2, Win(140, 0, 10))
    win_table.add_win(stake, WinType.SCATTER_WIN, tuple('X')*3, Win(240, 0, 10))

    line_evaluator.add_lines(3, [[0, 0, 0, 0, 0], [1, 1, 1, 1, 1], [2, 2, 2, 2, 2]])
    line_evaluator.add_lines(5, [[0, 0, 0, 0, 0], [1, 1, 1, 1, 1], [2, 2, 2, 2, 2], [0, 0, 1, 2, 2], [2, 2, 1, 0, 0]])


def main():
    stake = 100

    reels = Reels()
    win_table = SlotWinTable()
    line_evaluator = ReelLineEvaluator(reels, win_table)
    scatter_evaluator = ReelScatterEvaluator(reels, win_table)

    inject_spec(reels, win_table, line_evaluator)

    reels.change_current_reels_key("free")
    line_evaluator.set_lines(5)

    game = SlotGame(reels, win_table, [line_evaluator, scatter_evaluator])
    game.stake = 100

    iterations = 10000
    for i in range(iterations):
        game.play()

    quota = game.total_win / (iterations * stake)
    print(game.stat)

    print(quota)


if __name__ == "__main__":
    main()
