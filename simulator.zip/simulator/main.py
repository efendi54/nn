from reels import Reels
from meter_win import MeterWin
from win_table import SlotWinTable, WinType, TableWin
from win_evaluator import ReelLineEvaluator, ReelScatterEvaluator
from game import SlotGame, GameMode


def inject_spec(reels, win_table, line_evaluator):
    reels.add_reels(GameMode.BASE_MODE,
                    [["Book", "Ten", "Queen", "Ace", "Jack", "King", "Queen", "Ace", "Man", "Ten", "Ace", "Carpet",
                      "Queen", "King", "Woman", "Jack","Ace", "Ten", "Queen", "Carpet", "Jack", "King", "Saber",
                      "Queen", "King", "Ace", "Jack", "Carpet", "King","Queen", "Carpet", "King", "Ten", "Woman",
                      "Queen", "King", "Jack", "Ace", "Saber", "King", "Queen", "Carpet", "Ace", "King", "Man",
                      "Queen", "Ace", "Carpet", "Jack", "Ace"],

                     ["Saber", "King", "Ten", "Jack", "King", "Ten", "Jack", "Ace", "King", "Ten","Queen", "Woman",
                      "King", "Jack", "Saber", "Ten", "King", "Saber", "Jack", "Ace", "King", "Woman", "Jack", "Ten",
                      "Ace", "Book", "Queen", "Jack", "Ten", "Queen","King", "Ten", "Jack", "Carpet", "Ace", "King",
                      "Jack", "Saber", "Ten", "Jack", "Queen", "Man", "King", "Ten", "Jack"],

                     ["Carpet", "Ten", "Jack", "Man", "Queen", "Ten", "Woman", "Queen", "Ace", "Woman", "King",
                      "Ten", "Ace", "Jack", "Ten", "Book", "Ace", "Jack", "Ten", "Queen", "Jack", "Saber", "Ace",
                      "Ten", "Carpet", "Queen", "Jack", "Saber", "Ten", "Ace", "King", "Woman", "Ten", "Jack",
                      "Queen", "Saber", "Ten", "Ace", "Queen", "Jack", "Woman", "Ten", "Jack", "Man", "Ace", "King",
                      "Carpet", "Ace", "Queen"],

                     ["Carpet", "Ace", "Woman", "Queen", "Ace", "Man", "King", "Ten", "Book", "Jack", "Queen", "Ace",
                      "Ten", "Carpet", "Queen", "Jack", "Ten", "Woman", "King", "Queen", "Ten", "Jack", "Saber",
                      "Ace", "Ten", "Carpet", "King", "Queen", "Jack", "Ace", "Saber", "King", "Woman", "Ten",
                      "Queen", "Saber", "Ace", "Queen", "Book", "King", "Queen", "Carpet", "Ace", "King", "Carpet",
                      "Queen", "Ten", "Man", "Jack", "King"],

                     ["Queen", "King", "Carpet", "Ace", "Queen", "Carpet", "Jack", "King", "Book", "Jack", "Ten",
                      "King", "Ace", "Man", "Jack", "King", "Carpet", "Ten", "Jack", "Man", "Queen", "Woman", "King",
                      "Saber", "Ten", "Ace", "Saber", "Queen", "Carpet", "King", "Ace", "Woman", "Jack", "Queen",
                      "Book", "Ten", "Ace", "Carpet", "Queen", "Woman", "Jack", "Saber", "Ace", "Queen", "Saber",
                      "Ten"]],
                    [3, 3, 3, 3, 3])

    reels.add_reels(GameMode.FREE_MODE,
                    [["Queen", "Woman", "Ace", "Jack", "King", "Ten", "Carpet", "Ace", "King", "Man", "Jack", "King",
                      "Woman", "Jack", "Ace", "Queen", "Saber", "Ace", "King", "Carpet", "Jack", "Queen", "Saber",
                      "Ace", "King", "Queen", "Man", "Jack", "King", "Book", "Ten", "Queen", "Woman", "Jack", "Ace",
                      "Book", "Ten"],

                     ["Saber", "Jack", "Queen", "Ace", "Jack", "Woman", "Ten", "Queen", "Jack", "Ace", "Carpet",
                      "King", "Ten", "Ace", "Book", "Queen", "Jack", "Saber", "Ace", "Jack", "Man", "Queen", "Ten",
                      "Ace", "Queen",
                      "King", "Book", "Jack", "Saber", "Ten", "King", "Carpet", "Queen", "Ten", "King", "Ace", "Ten"],

                     ["Carpet", "Queen", "Jack", "King", "Man", "Ten", "Queen", "Man", "Ace", "Jack", "King",
                      "Carpet", "Queen", "Ten", "Woman", "Jack", "King", "Ten", "Book", "Ace", "Jack", "Ten",
                      "King", "Jack", "Ace",
                      "Queen", "Woman", "King", "Ace", "Ten", "Man", "Ace", "Queen", "Saber", "King", "Jack"],

                     ["Queen", "Saber", "Ten", "King", "Carpet", "Ten", "King", "Book", "Ace", "Jack", "Man", "Ten",
                      "Jack", "Ace", "Saber", "Ten", "Queen", "Carpet", "King", "Ten", "Saber", "Queen", "King",
                      "Carpet",
                      "Queen", "Ace", "Man", "Jack", "Queen", "Woman", "King", "Saber", "Queen", "King", "Ten",
                      "Book", "Jack"],

                     ["Book", "Jack", "Ten", "Carpet", "Ace", "Queen", "Woman", "King", "Book", "Ten", "Saber",
                      "Queen", "Man", "Ten", "Woman", "Queen", "Saber", "King", "Carpet", "Queen", "Woman", "Ten",
                      "Saber", "King", "Man", "Ace", "Carpet", "Ten", "Jack", "Man", "Ace", "Jack", "Carpet", "Ace",
                      "Woman", "Jack", "King"]],
                    [3, 3, 3, 3, 3])

    stake = 100
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Ten',) * 3, MeterWin(50)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Ten',) * 4, MeterWin(250)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Ten',) * 5, MeterWin(1000)))

    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Jack',) * 3, MeterWin(50)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Jack',) * 4, MeterWin(250)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Jack',) * 5, MeterWin(1000)))

    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Queen',) * 3, MeterWin(50)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Queen',) * 4, MeterWin(250)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Queen',) * 5, MeterWin(1000)))

    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('King',) * 3, MeterWin(50)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('King',) * 4, MeterWin(400)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('King',) * 5, MeterWin(1500)))

    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Ace',) * 3, MeterWin(50)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Ace',) * 4, MeterWin(400)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Ace',) * 5, MeterWin(1500)))

    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Carpet',) * 2, MeterWin(50)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Carpet',) * 3, MeterWin(300)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Carpet',) * 4, MeterWin(1000)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Carpet',) * 5, MeterWin(7500)))

    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Saber',) * 2, MeterWin(50)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Saber',) * 3, MeterWin(300)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Saber',) * 4, MeterWin(1000)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Saber',) * 5, MeterWin(7500)))

    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Woman',) * 2, MeterWin(50)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Woman',) * 3, MeterWin(400)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Woman',) * 4, MeterWin(4000)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Woman',) * 5, MeterWin(20000)))

    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Man',) * 2, MeterWin(100)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Man',) * 3, MeterWin(1000)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Man',) * 4, MeterWin(10000)))
    win_table.add_win(stake, TableWin(WinType.LINE_WIN, ('Man',) * 5, MeterWin(50000)))

    win_table.add_win(stake, TableWin(WinType.SCATTER_WIN, ('Book',) * 3, MeterWin(100, 0, 10)))
    win_table.add_win(stake, TableWin(WinType.SCATTER_WIN, ('Book',) * 4, MeterWin(1000, 0, 10)))
    win_table.add_win(stake, TableWin(WinType.SCATTER_WIN, ('Book',) * 5, MeterWin(10000, 0, 10)))

    line_evaluator.add_lines(5, [[0, 0, 0, 0, 0], [1, 1, 1, 1, 1], [2, 2, 2, 2, 2], [0, 1, 2, 1, 0], [2, 1, 0, 1, 2]])


def main():
    stake = 100

    reels = Reels()
    win_table = SlotWinTable()
    line_evaluator = ReelLineEvaluator(reels, win_table)
    scatter_evaluator = ReelScatterEvaluator(reels, win_table)

    inject_spec(reels, win_table, line_evaluator)

    reels.change_current_reels_key(GameMode.BASE_MODE)
    line_evaluator.set_lines(5)

    game = SlotGame(reels, win_table, [line_evaluator, scatter_evaluator])
    game.stake = 100

    stakes_paid = 0

    iterations = 100000
    for i in range(iterations):
        if game.mode == GameMode.BASE_MODE:
            stakes_paid += stake
        game.play()

    quota = game.total_win / stakes_paid * 100
    print(game.stat)

    print(quota)


if __name__ == "__main__":
    main()
