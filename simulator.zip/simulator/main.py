from reels import Reels, Stripes, ReelEvaluator, WinTable, Win


def inject_stripes(reels):
    reels.add_stripes("base",
                      Stripes(
                          [['A', 'K', 'T', '6', 'B'],
                           ['A', 'A', 'K', '6', 'T'],
                           ['X', 'A', 'T', 'A', 'K'],
                           ['T', 'K', 'K', 'A', 'B'],
                           ['A', 'K', 'X', 'B', 'K']],
                          [3, 3, 3, 3, 3],
                          [[0, 0, 0, 0, 0], [1, 1, 1, 1, 1], [2, 2, 2, 2, 2]]))

    reels.add_stripes("free",
                      Stripes(
                          [['A', 'K', 'T', '6', 'B'],
                           ['A', 'A', 'K', '6', 'T'],
                           ['6', 'A', 'T', 'A', 'K'],
                           ['T', 'K', 'K', 'A', 'B'],
                           ['A', 'K', '6', 'B', 'K']],
                          [3, 3, 3, 3, 3],
                          [[0, 0, 0, 0, 0], [1, 1, 1, 1, 1], [2, 2, 2, 2, 2], [0, 0, 1, 2, 2], [2, 2, 1, 0, 0]]))


def inject_wintable(wintable, stake=None):
    wintable.add_line_win(stake, tuple('A') * 2, Win(30))
    wintable.add_line_win(stake, tuple('A') * 3, Win(80))
    wintable.add_line_win(stake, tuple('A') * 4, Win(1500))
    wintable.add_line_win(stake, tuple('A') * 5, Win(1260))

    wintable.add_line_win(stake, tuple('K') * 2, Win(10))
    wintable.add_line_win(stake, tuple('K') * 3, Win(400))
    wintable.add_line_win(stake, tuple('K') * 4, Win(1300))
    wintable.add_line_win(stake, tuple('K') * 5, Win(4000))

    wintable.add_scatter_win(stake, tuple('X'), Win(40, 0, 10))


def play_games(iterations, stake, stripe_key, reels, evaluator, win_matrix):
    reels.change_current_stripe_key(stripe_key)
    total_win = 0
    for i in range(iterations):
        reels.spin()
        evaluator.calculate_win(stake, reels, win_matrix)
        total_win += evaluator.total_win
    print(evaluator.stat)
    print(total_win / (iterations*stake) * 100)


def main():
    stake = 100

    reels = Reels()
    inject_stripes(reels)

    win_table = WinTable()
    inject_wintable(win_table, stake)

    evaluator = ReelEvaluator()
    #play_games(1000000, stake, "base", reels, evaluator, win_table)
    play_games(500000, stake, "free", reels, evaluator, win_table)


if __name__ == "__main__":
    main()
