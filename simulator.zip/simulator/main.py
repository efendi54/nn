from slot_game import SlotGame
from simulator import Simulator


def main():
    sim = Simulator()
    sim.iterations = 10000000

    sg = SlotGame()
    sg.stake = 100

    sim.simulate(sg)

if __name__ == "__main__":
    main()
