from reels import Reels, Stripes, ReelEvaluator, WinMatrix
import time, datetime

def inject_stripes(reels):
    reels.add_stripes("base",
                      Stripes(
                          [['A', 'K', 'T', '6', 'B'],
                           ['A', 'A', 'K', '6', 'T'],
                           ['6', 'A', 'T', 'A', 'K'],
                           ['T', 'K', 'K', 'A', 'B'],
                           ['A', 'K', '6', 'B', 'K']],
                          [3, 3, 3, 3, 3],
                          [[0, 0, 0, 0, 0], [1, 1, 1, 1, 1], [2, 2, 2, 2, 2]]))

    reels.add_stripes("free",
                      Stripes(
                          [['A', 'K', 'T', '6', 'B'],
                           ['A', 'A', 'K', '6', 'T'],
                           ['6', 'A', 'T', 'A', 'K'],
                           ['T', 'K', 'K', 'A', 'B'],
                           ['A', 'K', '6', 'B', 'K']],
                          [3, 3, 3, 3, 3],
                          [[0, 0, 0, 0, 0], [1, 1, 1, 1, 1], [2, 2, 2, 2, 2], [0, 0, 1, 2, 2], [2, 2, 1, 0, 0]]))


def play_games(iterations, stake, stripe_key, reels, evaluator, win_matrix):
    reels.change_current_stripe_key(stripe_key)
    total_win = 0
    for i in range(iterations):
        reels.spin()
        evaluator.calculate_win(stake, reels, win_matrix)
        total_win += evaluator.total_win
    print(evaluator.stat)
    print(total_win / (iterations*stake) * 100)


def main():
    stake = 100

    reels = Reels()
    inject_stripes(reels)

    evaluator = ReelEvaluator()

    win_matrix = WinMatrix()
    win_matrix.add_symbol_win(stake, tuple('A') * 2, 30)
    win_matrix.add_symbol_win(stake, tuple('A') * 3, 80)
    win_matrix.add_symbol_win(stake, tuple('A') * 4, 1500)
    win_matrix.add_symbol_win(stake, tuple('A') * 5, 1260)

    win_matrix.add_symbol_win(stake, tuple('K') * 2, 10)
    win_matrix.add_symbol_win(stake, tuple('K') * 3, 400)
    win_matrix.add_symbol_win(stake, tuple('K') * 4, 1300)
    win_matrix.add_symbol_win(stake, tuple('K') * 5, 4000)

    play_games(1000000, stake, "base", reels, evaluator, win_matrix)
    #play_games(500000, stake, "free", reels, evaluator, win_matrix)


if __name__ == "__main__":
    main()
