

class WinMatrix:
    def __init__(self):
        self.win_map = dict()

    def add_win_eval(self, stake, winline, win, func=None):
        self.win_map[(stake, winline)] = (win, func)
