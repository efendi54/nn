from enum import Enum


class BetType(Enum):
    BASIC = 0
    MAXI = 1
    LINES = 2


class Bet:
    def __init__(self):
        self.bets = dict()

    def set_amount(self, bet_type=BetType.BASIC, amount=0):
        self.bets[bet_type] = amount

    def get_amount(self, bet_type=BetType.BASIC):
        if bet_type in self.bets:
            return self.bets[bet_type]
        return 0
