from game import Game
from reels import Reels
from winmatrix import WinMatrix


class SlotGame(Game):
    def __init__(self):
        Game.__init__(self)

        self.reels = Reels()
        self.reels.inject_stripes()

        self.win_matrix = WinMatrix()
        #self.win_matrix.add_win_eval(100, (2, 2, 2), 10)
        self.win_matrix.add_win_eval(100, (1, 5, 1), 20)
        self.win_matrix.add_win_eval(100, (5, 5, 5), 30, self.scatter_func)

    def start_game(self):
        Game.start_game(self)
        self.reels.spin()

    def evaluate_win(self):
        lines = self.reels.get_lines()
        for l in lines:
            key = (self.stake, l)
            if key in self.win_matrix.win_map:

                if l in self.stat:
                    self.stat[l] += 1
                else:
                    self.stat[l] = 1

                w = self.win_matrix.win_map[key]
                self.win += w[0]
                if w[1]:
                    w[1](key)

    def scatter_func(self, key):
        self.free_game_amount += 5

    def finish_game(self):
        Game.finish_game(self)
        self.total_wins += self.win

    def print_stats(self):
        print("total-wins = "+str(self.total_wins))
        print("paid stakes = "+str(self.paid_stakes))
        print("payout-quota = "+str(self.total_wins / self.paid_stakes))
        print("combinations occureances = ")
        for k, v in self.stat.items():
            print(str(k)+" --> "+str(v))

