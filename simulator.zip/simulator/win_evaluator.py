class WinEvaluator:
    def __init__(self):
        self.total_win = 0


class SlotLineEvaluation(WinEvaluator):
    def __init__(self, win_eval):
        WinEvaluator.__init__(self)
        self.win_eval = win_eval

    def calculate_win(self, reels):


