from collections import Counter
from win_table import WinType, TableWin


class SymbolWin:
    def __init__(self, positions, table_win):
        if not isinstance(table_win, TableWin):
            raise "missing table-win.."
        self.positions = positions
        self.table_win = table_win


class WinEvaluator:
    def __init__(self):
        pass

    def calculate_win(self, stake):
        return []


class ReelEvaluator(WinEvaluator):
    def __init__(self, reels, win_table):
        WinEvaluator.__init__(self)
        self.reels_window = []
        self.reels = reels
        self.win_table = win_table


class ReelScatterEvaluator(ReelEvaluator):
    def __init__(self, reels, win_table):
        ReelEvaluator.__init__(self, reels, win_table)

    def calculate_win(self, stake):
        wins = []
        self.reels_window, lines = self.reels.get_window_and_lines()

        # scatter-evaluation (flattening the reel-window first ..)
        flat = [item for sublist in self.reels_window for item in sublist]
        symbol_counts = Counter(flat)

        for key, table_win in self.win_table.wins[WinType.SCATTER_WIN].items():
            scatter_comb = table_win.combination
            scatter_symbol = table_win.combination[0]
            if scatter_symbol in symbol_counts and len(scatter_comb) == symbol_counts[scatter_symbol]:
                positions = tuple([index for index, value in enumerate(flat) if value == scatter_symbol])
                wins += [SymbolWin(positions, table_win)]

        return wins


class ReelLineEvaluator(ReelEvaluator):
    def __init__(self, reels, win_table):
        ReelEvaluator.__init__(self, reels, win_table)

        self.lines = dict()
        self.current_lines_key = None

    def add_lines(self, key, lines):
        if self.reels.lines_ok(lines):
            self.lines[key] = lines
            self.set_lines(key)

    def set_lines(self, key):
        self.current_lines_key = key

    def calculate_win(self, stake):
        wins = []
        self.reels_window, lines = self.reels.get_window_and_lines(self.lines[self.current_lines_key])

        # usual win-line evaluation
        for idx, (line_content, positions) in enumerate(lines):
            while line_content:
                table_win = self.win_table.get_win(stake, WinType.LINE_WIN, line_content)
                if table_win:
                    wins += [SymbolWin(positions, table_win)]
                    break
                line_content = line_content[:-1]

        return wins
