from copy import copy


class MeterWin:
    def __init__(self, points=0, giga_spins=0, free_games=0):
        self.points = points
        self.giga_spins = giga_spins
        self.free_games = free_games

    def __add__(self, other):
        report = copy(self)
        report.points += other.points
        report.giga_spins += other.giga_spins
        report.free_games += other.free_games
        return report

    def reset(self):
        self.points = 0
        self.free_games = 0
        self.giga_spins = 0

    def print(self):
        print((self.points, self.giga_spins, self.free_games))
