from enum import Enum
from meter_win import MeterWin


class GameMode(Enum):
    BASE_MODE = 0
    FREE_MODE = 1


class Game:
    GIGA_SPIN_VALUE = 100

    def __init__(self):
        self.stake = 0
        self.win_meter = MeterWin()
        self.total_win = 0
        self.free_games = 0
        self.mode = GameMode.BASE_MODE

    def play(self):
        self.pre_single_game()
        self.evaluate()
        self.post_single_game()

    def pre_single_game(self):
        pass

    def post_single_game(self):
        pass

    def evaluate(self):
        pass


class SlotGame(Game):

    def __init__(self, reels, win_table, evaluators):
        Game.__init__(self)
        self.reels = reels
        self.win_table = win_table
        self.evaluators = evaluators
        self.stat = dict()
        self.wins = []

    def evaluate(self):
        for e in self.evaluators:
            self.wins += e.calculate_win(self.stake)
            for w in self.wins:
                symbols = w.table_win.combination
                win = w.table_win.meter_win
                self.win_meter += win
                func = w.table_win.func
                # statistics ..
                if symbols not in self.stat:
                    self.stat[symbols] = 0
                self.stat[symbols] += 1

    def pre_single_game(self):
        self.mode = GameMode.BASE_MODE
        if self.free_games > 0:
            self.mode = GameMode.FREE_MODE
            self.free_games -= 1
        self.reels.change_current_reels_key(self.mode)
        self.wins = []
        self.win_meter.reset()
        self.reels.spin()

    def post_single_game(self):
        self.total_win += self.win_meter.points
        self.total_win += self.win_meter.giga_spins * SlotGame.GIGA_SPIN_VALUE
        self.free_games += self.win_meter.free_games
