from bet import Bet


class Game:
    def __init__(self):
        self.stake = 100
        self.paid_stakes = 0
        self.win = 0
        self.total_wins = 0
        self.free_game_amount = 0
        self.stat = dict()

    def play_game(self):
        self.start_game()
        self.evaluate_win()
        self.finish_game()

    def start_game(self):
        self.win = 0
        if self.free_game_amount == 0:
            self.paid_stakes += self.stake
        if self.free_game_amount > 0:
            self.free_game_amount -= 1

    def evaluate_win(self):
        pass

    def finish_game(self):
        pass

    def print_stats(self):
        pass
