from win import Win


class Game:
    GIGA_SPIN_VALUE = 100

    def __init__(self):
        self.stake = 0
        self.win_meter = Win()
        self.total_win = 0
        self.free_games = 0

    def play(self):
        self.pre_single_game()
        self.evaluate()
        self.post_single_game()

    def pre_single_game(self):
        pass

    def post_single_game(self):
        pass

    def evaluate(self):
        pass


class SlotGame(Game):

    def __init__(self, reels, win_table, evaluators):
        Game.__init__(self)
        self.reels = reels
        self.win_table = win_table
        self.evaluators = evaluators
        self.stat = dict()
        self.wins = []

    def evaluate(self):
        for e in self.evaluators:
            self.wins += e.calculate_win(self.stake)
            for w in self.wins:
                symbols = w.win[0]
                win = w.win[1]
                func = w.win[2]
                self.win_meter += win
                # statistics ..
                if symbols not in self.stat:
                    self.stat[symbols] = 0
                self.stat[symbols] += 1
                if func:
                    func(w)

    def pre_single_game(self):
        self.wins = []
        self.win_meter.reset()
        self.reels.spin()

    def post_single_game(self):
        self.total_win += self.win_meter.points
        self.total_win += self.win_meter.giga_spins * SlotGame.GIGA_SPIN_VALUE
        self.free_games += self.win_meter.free_games
