from enum import Enum
from meter_win import MeterWin


class WinType(Enum):
    LINE_WIN = 0
    SCATTER_WIN = 1


class TableWin:
    def __init__(self, win_type, combination, meter_win, func=None):
        if not isinstance(meter_win, MeterWin):
            raise "Win needs to be of type MeterWin"
        self.combination = combination
        self.type = win_type
        self.meter_win = meter_win
        self.func = func


class SlotWinTable:
    def __init__(self):
        self.wins = dict()
        self.wins[WinType.LINE_WIN] = dict()
        self.wins[WinType.SCATTER_WIN] = dict()

    def add_win(self, stake, table_win):
        if isinstance(table_win.type, WinType):
            self.wins[table_win.type][(stake, table_win.combination)] = table_win

    def get_win(self, stake, win_type, sym_comb):
        if isinstance(win_type, WinType):
            if (stake, sym_comb) in self.wins[win_type]:
                return self.wins[win_type][(stake, sym_comb)]
        return None
