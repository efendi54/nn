from enum import Enum


class WinType(Enum):
    LINE_WIN = 0
    SCATTER_WIN = 1


class SlotWinTable:
    def __init__(self):
        self.wins = dict()
        self.wins[WinType.LINE_WIN] = dict()
        self.wins[WinType.SCATTER_WIN] = dict()

    def _win_type_known(self, win_type):
        if win_type not in self.wins:
            raise "Unknown win-type: "+str(win_type)
            return False
        return True

    def add_win(self, stake, win_type, sym_comb, win, func=None):
        if self._win_type_known(win_type):
            self.wins[win_type][(stake, sym_comb)] = (sym_comb, win, func)

    def couple_func(self, stake, win_type, sym_comb, func):
        if self._win_type_known(win_type):
            if (stake, sym_comb) in self.wins[win_type]:
                w = self.wins[win_type][(stake, sym_comb)][:-1]
                w += (func,)
                self.wins[win_type][(stake, sym_comb)] = w
            else:
                raise "Unknown symbol-combination:"+str((stake, sym_comb))

    def get_win(self, stake, win_type, sym_comb):
        if self._win_type_known(win_type):
            if (stake, sym_comb) in self.wins[win_type]:
                return self.wins[win_type][(stake, sym_comb)]
        return None
