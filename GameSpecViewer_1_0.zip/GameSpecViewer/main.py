#!/usr/bin/env python

from PyQt5 import QtWidgets, QtGui, QtCore, uic
from PyQt5.QtCore import pyqtSlot

import sys
import os
import copy
import logging
import logging.config

# keep that import although not necessary within current module (necessary for dependency detection for cx-freeze)!!
import json

import game_info_model
import stripe_model
import stripe_filter_model
import stripe_item_delegate

# add base-modules directory to sys.path
if getattr(sys, 'frozen', False):
    # frozen
    fp = os.path.dirname(sys.executable)
else:
    # unfrozen
    fp = os.path.dirname(os.path.realpath(__file__))

dir_path = os.path.join(fp, '..', '..')
sys.path.append(dir_path)
import game_spec

'''
    TODOS:
        1) invent validation of game-spec file (for cases when format is wrong or content not as expected) + reaction
        2) invent approach to read in game-infos in more generic way (not being depended by any cathegories [DONE]
'''


# ///////////////////////////////
class MainWindow(QtWidgets.QMainWindow):
    def __init__(self, parent=None):
        super(MainWindow, self).__init__()
        logging.config.fileConfig("pylog.conf")
        self.logger = logging.getLogger(__name__)
        self.logger.debug("Initializing Stripe-Viewer ..")

        # create ui ..
        self.ui = uic.loadUi("main.ui", self)

        # create model and wire it to game-info-table-view
        self.__game_info_model = game_info_model.GameInfoModel()
        self.ui.game_info_table_view.setModel(self.__game_info_model)
        self.ui.game_info_table_view.horizontalHeader().setStretchLastSection(True)
        self.ui.game_info_table_view.resizeColumnsToContents()

        # create model and wire it to stripe-table-view
        self.__stripe_model = stripe_model.StripeModel()
        self.ui.stripe_table_view.setModel(self.__stripe_model)
        self.__stripe_selection_model = self.ui.stripe_table_view.selectionModel()

        # create filter-model and wire it to stripe-filter-table-view ..
        self.__stripe_filter_model = stripe_filter_model.StripeFilterModel()
        self.ui.filter_stripe_table_view.setModel(self.__stripe_filter_model)
        self.__filter_selection_model = self.ui.filter_stripe_table_view.selectionModel()
        sid = stripe_item_delegate.StripeItemDelegate()
        self.ui.filter_stripe_table_view.setItemDelegate(sid)
        self.__stripe_filter_model.dataChanged.connect(self.__search_symbols)
        self.ui.filter_stripe_table_view.hide()

        # wire up user-defined callbacks for existing widgets ..
        self.ui.up_button.clicked.connect(self.__handle_up_button_click)
        self.ui.down_button.clicked.connect(self.__handle_down_button_click)
        self.ui.reload_button.clicked.connect(self.__reset_stripe_rotation)
        self.ui.search_button.clicked.connect(self.__toogle_filter_view_visibility)
        self.ui.forward_button.clicked.connect(self.__rotate_stripes_and_filters)
        self.ui.reel_set_combo_box.currentIndexChanged.connect(self.__reel_stripe_idx_changed)

        self.__stripe_selection_model.selectionChanged.connect(self.__check_for_selected_columns)

        self.__game_spec = None
        self.__all_stripes = []
        self.__all_window_sizes = []
        self.__all_symbols = []
        self.__all_filter_results = []

        # game-info related stuff ..
        self.__game_info = []
        self.__game_info_colors = dict()
        self.__game_info_colors["quotas"] = QtGui.QBrush(QtGui.QColor(190, 150, 150))
        self.__game_info_colors["stakes"] = QtGui.QBrush(QtGui.QColor(170, 170, 110))
        self.__game_info_colors["play_cfg"] = QtGui.QBrush(QtGui.QColor(190, 110, 190))

    # --------------------------------
    @pyqtSlot()
    def __search_symbols(self):
        self.__all_filter_results = []
        stripes = [list(z) for z in list(zip(*self.__stripe_model.stripes))]
        for s_i, s in enumerate(stripes):
            c = self.__stripe_filter_model.get_symbols_to_filter(s_i)
            pos = self.find_sub_list(c, s)
            pos = [x + self.__stripe_model.stripe_indices[s_i] for x in pos]
            self.__all_filter_results.append(pos)

        fl = [len(f) for f in self.__all_filter_results]
        self.__stripe_filter_model.update_column_colors(fl)
        fl2 = [x > 1 for x in fl]
        self.ui.forward_button.setEnabled(any(fl2))
        self.logger.debug(self.__all_filter_results)
        self.__rotate_stripes_and_filters()

    # --------------------------------
    @pyqtSlot()
    def __rotate_stripes_and_filters(self):
        # only rotate selected ones or all (if none is chosen)
        selected_columns = [x.column() for x in self.__stripe_selection_model.selectedColumns()]
        for fr_i, fr in enumerate(self.__all_filter_results):
            idx_ok = True
            if len(selected_columns) > 0:
                idx_ok = fr_i in selected_columns
            if idx_ok and fr:
                pos = self.__all_filter_results[fr_i][0]
                c_i = self.__stripe_model.stripe_indices[fr_i]
                self.__stripe_model.rotate_stripe(fr_i, pos - c_i)
                self.__all_filter_results[fr_i] = self.__all_filter_results[fr_i][1:] + [pos]
        self.logger.debug(self.__all_filter_results)

    # --------------------------------
    @pyqtSlot()
    def __toogle_filter_view_visibility(self):
        if self.ui.filter_stripe_table_view.isVisible():
            self.ui.filter_stripe_table_view.hide()
        else:
            self.ui.filter_stripe_table_view.show()

    # --------------------------------
    @pyqtSlot()
    def __check_for_selected_columns(self):
        enable = len(self.__stripe_selection_model.selectedColumns()) > 0
        self.ui.up_button.setEnabled(enable)
        self.ui.down_button.setEnabled(enable)

    # --------------------------------
    def __resize_table_views(self, show=False):
        self.ui.stripe_table_view.resizeColumnsToContents()
        self.ui.filter_stripe_table_view.resizeColumnsToContents()
        if show:
            self.ui.stripe_table_view.show()
            self.ui.filter_stripe_table_view.show()

    # --------------------------------
    @pyqtSlot(int)
    def __reel_stripe_idx_changed(self, index):
        if not self.__all_stripes:
            return
        self.__stripe_model.set_stripes(copy.deepcopy(self.__all_stripes[index]),
                                        copy.deepcopy(self.__all_window_sizes[index]))
        self.__stripe_filter_model.set_stripes(copy.deepcopy(self.__all_stripes[index]),
                                               copy.deepcopy(self.__all_window_sizes[index]))
        self.__resize_table_views()
        self.__search_symbols()

    # --------------------------------
    @pyqtSlot()
    def __reset_stripe_rotation(self):
        self.__stripe_model.reset_stripe_rotation()

    # --------------------------------
    @pyqtSlot()
    def __handle_up_button_click(self):
        for col in self.__stripe_selection_model.selectedColumns():
            self.__stripe_model.rotate_stripe(col.column(), 1)

    # --------------------------------
    @pyqtSlot()
    def __handle_down_button_click(self):
        for col in self.__stripe_selection_model.selectedColumns():
            self.__stripe_model.rotate_stripe(col.column(), -1)

    # --------------------------------
    @pyqtSlot()
    def __handle_marked_row_count_selection(self, index):
        self.__stripe_model.markedRowCount = int(self.ui.reel_set_combo_box.currentText())
        self.__stripe_model.layoutChanged.emit()

    # --------------------------------
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            urls = e.mimeData().urls()
            if not urls or len(urls) > 1:
                e.ignore()
                return
            else:
                e.accept()
        else:
            e.ignore()

    # --------------------------------
    def dropEvent(self, e):
        if e.mimeData().hasUrls():
            urls = e.mimeData().urls()
            if not urls or len(urls) > 1:
                e.ignore()
                return
            else:
                e.accept()
            spec_file_name = str(urls[0].toLocalFile())
            self.open_spec_file(spec_file_name)
        else:
            e.ignore()

    # --------------------------------
    @staticmethod
    def find_sub_list(sub, bigger):
        if not bigger or not sub:
            return []
        first, rest = sub[0], sub[1:]
        result = []
        pos = 0
        try:
            while True:
                pos = bigger.index(first, pos)
                n_pos = pos + 1
                tmp = list(bigger)
                tmp = list(filter(None, tmp[n_pos:] + tmp[:pos]))  # filter out empty string extensions
                if tmp[:len(rest)] == rest:
                    result.append(pos)
                pos = n_pos
        except ValueError:
            return result

    # ///////////////////////////////
    def __add_game_info(self, cathegory):
        if not self.__game_spec:
            return
        data = self.__game_spec.get_attribute(cathegory)
        if not data:
            return
        result = []
        for k, v in data.items():
            # CAUTION: data will hold game-info cathegory in column-0 for each row
            result.append([cathegory, cathegory+" / "+str(k), str(v)])
        if result:
            self.__game_info += result

    # --------------------------------
    def open_spec_file(self, spec_file_name=None):
        if not spec_file_name:
            spec_file_name = self.__select_file_with_dialog()
        if not spec_file_name:
            return
        self.__read_spec(spec_file_name)

    # --------------------------------
    def __select_file_with_dialog(self):
        gs_file_selection = QtWidgets.QFileDialog.getOpenFileName(self, "Open Game-Spec", ".", "*.json")
        if not gs_file_selection or not gs_file_selection[0]:
            return None
        return gs_file_selection[0]

    # --------------------------------
    def __clear_gui_data(self):
        del self.__all_stripes[:]
        del self.__all_window_sizes[:]
        del self.__all_symbols[:]
        del self.__game_info[:]

    # --------------------------------
    def __read_spec(self, spec_file_name):
        try:
            self.__clear_gui_data()
            self.ui.reel_set_combo_box.clear()

            self.logger.debug("Reading in "+spec_file_name)

            # retrieve game-spec ..
            # TODO: add here some validation-checking before proceeding to retrieve game-spec content (it could be any content / file-type otherwise)
            self.__game_spec = game_spec.GameSpec(spec_file_name)

            #cfg = self.__game_spec.get_game_cfgs()

            # retrieve all game-info ..
            self.__add_game_info("quotas")
            self.__add_game_info("stakes")
            self.__add_game_info("play_cfg")
            self.__game_info_model.set_game_info(self.__game_info)
            self.__game_info_model.set_game_info_colors(self.__game_info_colors)
            self.ui.game_info_table_view.resizeColumnsToContents()

            # change title of group-box to game-name/id
            self.ui.game_info_group_box.setTitle(
                self.__game_spec.get_game_name() + " " +
                self.__game_spec.get_game_id())

            reel_set = self.__game_spec.get_reel_set()
            self.__all_symbols = self.__game_spec.get_reel_symbol_enum()
            for rs in reel_set:
                self.ui.reel_set_combo_box.addItem(rs["mode"])
                stripe_cfg = rs["stripes"]
                reel_window_sizes = rs["window_sizes"]
                reel_stripes = []
                max_stripe_size = 0
                for s in stripe_cfg:
                    s_arr = s.split(',')
                    max_stripe_size = max(len(s_arr), max_stripe_size)
                    reel_stripes.append(s_arr)
                if reel_stripes:
                    for i, s in enumerate(reel_stripes):
                        if len(s) < max_stripe_size:
                            s += ['']*(max_stripe_size-len(s))
                            reel_stripes[i] = s
                    reel_stripes = list(map(list, zip(*reel_stripes)))
                    self.__all_stripes.append(reel_stripes)
                    self.__all_window_sizes.append(reel_window_sizes)

            # enable/-disable tool-buttons ..
            self.ui.reel_set_combo_box.setEnabled(True)
            self.ui.reload_button.setEnabled(True)
            self.ui.search_button.setEnabled(True)
            self.__check_for_selected_columns()

            # at least one stripe was found ..
            if len(self.__all_stripes) > 0:
                self.logger.debug("Stripes found ..")
                self.ui.filter_stripe_table_view.itemDelegate().set_symbols(self.__all_symbols)
                self.__reel_stripe_idx_changed(0)
                self.__resize_table_views(True)
                self.statusBar().showMessage(spec_file_name)

        except Exception as e:
            msg_box = QtWidgets.QMessageBox()
            msg_box.setIcon(QtWidgets.QMessageBox.Critical)
            msg_box.setInformativeText("Could not import stripes from game-spec file: \n" +
                e.__class__.__name__ + " : " + str(e))
            msg_box.setWindowTitle("Error")
            msg_box.setStandardButtons(QtWidgets.QMessageBox.Ok)
            msg_box.exec_()


# ///////////////////////////////
def main(argv):

    app = QtWidgets.QApplication(sys.argv)
    app.setStyle("plastique")
    try:
        mw = MainWindow()
        mw.show()
    except BaseException as e:
        msg_box = QtWidgets.QMessageBox()
        msg_box.setIcon(QtWidgets.QMessageBox.Critical)
        msg_box.setInformativeText("Something went wrong: \n" +
                                   e.__class__.__name__ + " : " + str(e))
        msg_box.setWindowTitle("Error")
        msg_box.setStandardButtons(QtWidgets.QMessageBox.Ok)
        msg_box.exec_()

    sys.exit(app.exec_())


# ///////////////////////////////
if __name__ == "__main__":
    main(sys.argv)
