from PyQt5 import QtCore, QtGui


# //////////////////////////////////////////////////
class StripeFilterModel(QtCore.QAbstractTableModel):
    def __init__(self, parent=None):
        QtCore.QAbstractTableModel.__init__(self, parent)
        self.stripes = []
        self.window_sizes = []
        self.column_colors = []

    # --------------------------------
    def __reset_stripes(self):
        self.beginResetModel()
        del self.stripes
        self.stripes = []
        self.endResetModel()

    # --------------------------------
    def update_column_colors(self, filter_result_lengths):
        self.column_colors = [x > 0 for x in filter_result_lengths]

    # --------------------------------
    def get_symbols_to_filter(self, s_i):
        s = list(zip(*self.stripes))
        return list(s[s_i][:self.window_sizes[s_i]])

    # --------------------------------
    def set_stripes(self, s, w):
        stripes = list(s)
        window_sizes = list(w)
        if len(stripes) > 0:
            self.__reset_stripes()
            for s in stripes:
                self.beginInsertRows(QtCore.QModelIndex(), len(self.stripes), len(self.stripes))
                self.stripes.append(s)
                self.endInsertRows()
        self.column_colors = [False] * len(window_sizes)
        self.window_sizes = window_sizes
        max_arr_len = max(window_sizes)
        self.beginRemoveRows(QtCore.QModelIndex(), max_arr_len, len(self.stripes))
        del self.stripes[max_arr_len:]
        self.endRemoveRows()
        self.layoutChanged.emit()

    # --------------------------------
    def rowCount(self, parent):
        return len(self.stripes)

    # --------------------------------
    def columnCount(self, parent):
        if self.stripes:
            return len(self.stripes[0])
        return 0

    # --------------------------------
    def flags(self, index):
        if not index.isValid():
            return QtCore.Qt.NoItemFlags
        if index.row() < self.window_sizes[index.column()]:
            return QtCore.Qt.ItemIsEnabled | QtCore.Qt.ItemIsSelectable | QtCore.Qt.ItemIsEditable
        return QtCore.Qt.NoItemFlags

    # --------------------------------
    def setData(self, index, data, role=None):
        if role == QtCore.Qt.EditRole:
            self.stripes[index.row()][index.column()] = data
            self.dataChanged.emit(index, index)

    # --------------------------------
    def data(self, index, role):
        if not index.isValid():
            return QtCore.QVariant()
        elif role == QtCore.Qt.BackgroundRole:
            if index.row() < self.window_sizes[index.column()]:
                color = QtGui.QBrush(QtCore.Qt.yellow)
                if self.column_colors and self.column_colors[index.column()]:
                    color = QtGui.QBrush(QtCore.Qt.green)
                return color
        elif role == QtCore.Qt.TextAlignmentRole:
            return QtCore.Qt.AlignCenter
        elif role != QtCore.Qt.DisplayRole:
            return QtCore.QVariant()

        # only populate those that are within window_sizes ..
        if index.row() < self.window_sizes[index.column()]:
            return QtCore.QVariant(self.stripes[index.row()][index.column()])
        return QtCore.QVariant()

