from PyQt5 import QtGui, QtCore


# //////////////////////////////////////////////////
class StripeModel(QtCore.QAbstractTableModel):
    def __init__(self, parent=None):
        QtCore.QAbstractTableModel.__init__(self, parent)
        self.stripes = []
        self.stripe_indices = []
        self.reset_stripes()
        self.window_sizes = []

    # --------------------------------
    def rowCount(self, parent):
        return len(self.stripes)

    # --------------------------------
    def columnCount(self, parent):
        if len(self.stripes) > 0:
            return len(self.stripes[0])
        return 0

    # --------------------------------
    def data(self, index, role):
        if not index.isValid():
            return QtCore.QVariant()
        elif role == QtCore.Qt.BackgroundRole:
            if index.row() < self.window_sizes[index.column()]:
                return QtGui.QBrush(QtCore.Qt.yellow)
        elif role == QtCore.Qt.TextAlignmentRole:
            return QtCore.Qt.AlignCenter
        elif role != QtCore.Qt.DisplayRole:
            return QtCore.QVariant()
        return QtCore.QVariant(self.stripes[index.row()][index.column()])

    # --------------------------------
    def reset_stripes(self):
        self.beginResetModel()
        del self.stripes[:]
        self.stripes = []
        self.stripe_indices = []
        self.endResetModel()

    # --------------------------------
    def set_stripes(self, s, w):
        stripes = list(s)
        window_sizes = list(w)
        if len(stripes) > 0:
            self.reset_stripes()
            for s in stripes:
                self.beginInsertRows(QtCore.QModelIndex(), len(self.stripes), len(self.stripes))
                self.stripes.append(s)
                self.endInsertRows()
        self.__reset_stripe_indices()
        self.window_sizes = window_sizes
        self.layoutChanged.emit()

    # --------------------------------
    @staticmethod
    def stripe_size(stripe):
        i = 0
        try:
            i = stripe.index('')
        except ValueError:
            i = len(stripe)
        return i

    # --------------------------------
    def reset_stripe_rotation(self):
        for s_idx in range(len(self.stripes[0])):
            self.rotate_stripe(s_idx, -self.stripe_indices[s_idx])
        self.__reset_stripe_indices()

    # --------------------------------
    def __reset_stripe_indices(self):
        self.stripe_indices = [0 for x in self.stripes[0]]

    # --------------------------------
    def headerData(self, section, orientation, role=QtCore.Qt.DisplayRole):
        if role == QtCore.Qt.DisplayRole and orientation == QtCore.Qt.Horizontal:
            return str(self.stripe_indices[section])
        return QtCore.QAbstractTableModel.headerData(self, section, orientation, role)

    # --------------------------------
    def rotate_stripe(self, stripe_idx, shift):
        all_rotated = list(zip(*self.stripes))
        if stripe_idx >= len(all_rotated):
            return
        if shift == 0:
            return

        self.layoutAboutToBeChanged.emit()
        stripe_tuple = all_rotated[stripe_idx]
        shifted = []

        s = list(stripe_tuple)
        end_s = self.stripe_size(s)
        tmp_s = s[:end_s]

        new_s = tmp_s[shift:] + tmp_s[:shift]
        s[:end_s] = new_s

        all_rotated[stripe_idx] = tuple(s)

        for rs in all_rotated:
            shifted.append(list(rs))

        sz = self.stripe_size(all_rotated[stripe_idx])
        off_set = shift
        if shift < 0:
            off_set = sz - abs(shift)
        self.stripe_indices[stripe_idx] = (self.stripe_indices[stripe_idx] + off_set) % sz

        all_rotated = list(zip(*shifted))
        self.stripes = [list(x) for x in all_rotated]

        self.layoutChanged.emit()
        #print(self.stripe_indices)
