from PyQt5 import QtCore, QtWidgets


# //////////////////////////////////////////////////
class StripeItemDelegate(QtWidgets.QItemDelegate):
    def __init__(self, parent=None):
        QtWidgets.QItemDelegate.__init__(self, parent)
        self.symbols = []

    # -----------------------------
    def set_symbols(self, symbols):
        self.symbols = symbols[:]

    # -----------------------------
    def createEditor(self, parent, option, index):
        cb = QtWidgets.QComboBox(parent)
        cb.addItems(self.symbols)
        cb.setSizeAdjustPolicy(QtWidgets.QComboBox.AdjustToContents)
        return cb

    # -----------------------------
    def setEditorData(self, editor, index):
        ds = index.model().data(index, QtCore.Qt.DisplayRole)
        pos = self.symbols.index(ds)
        if pos >= 0:
            editor.setCurrentIndex(pos)

    # -----------------------------
    def setModelData(self, editor, model, index):
        cs = editor.currentText()
        model.setData(index, cs, QtCore.Qt.EditRole)

    # -----------------------------
    def updateEditorGeometry(self, editor, option, index):
        editor.setGeometry(option.rect)
