import json
import logging
import logging.config
import hashlib


class GameSpec(object):
    __primes = []

    # -----------------------------
    def __init__(self, spec_file_name):

        logging.config.fileConfig("pylog.conf")
        self.logger = logging.getLogger(__name__)
        self.logger.debug("Initializing Game-Spec ..")

        self.gs = []
        self.reels = []
        self.code_comment = []
        if not self.__primes:
            limit = 1000
            self.logger.debug("Generating " + str(limit) + " primes ..")
            self.__primes = self.__gen_primes(limit)

        self.__read_spec(spec_file_name)

    # --------------------------------
    @staticmethod
    def __gen_primes(limit):
        is_prime = [False] * 2 + [True] * (limit - 1)

        # stop at sqrt(limit) ..
        for n in range(int(limit ** 0.5 + 1.5)):
            if is_prime[n]:
                for i in range(n * n, limit + 1, n):
                    is_prime[i] = False
        return [i for i, prime in enumerate(is_prime) if prime]

    # -----------------------------
    def __read_spec(self, spec_file_name):
        json_file = open(spec_file_name)
        d = json.load(json_file)
        self.gs = d["game_spec"]
        self.code_comment = "/*\n CAUTION: GENERATED SOURCE CODE. " \
                            "DO NOT MODIFY BY HAND.\n {:s} \n GAME-SPEC-VERSION: {:s}\n*/".format(self.gs["name"],
                                                                                                  self.gs["version"])
        self.reels = self.gs["reels"]
        self.__validity_check()

    # -----------------------------
    def get_attribute(self, att_name):
        try:
            return self.gs[att_name]
        except KeyError:
            return None

    # -----------------------------
    # returns stake settings
    def get_stakes(self):
        if not self.gs:
            return dict()
        return self.get_attribute("stakes")

    # -----------------------------
    # returns name of the game to whom game-spec-file belongs
    def get_game_name(self):
        if not self.gs:
            return "?"
        return self.gs["name"]

    # -----------------------------
    # returns name of the game to whom game-spec-file belongs
    def get_game_id(self):
        if not self.gs:
            return "?"
        return str(self.gs["game_id"])

    # -----------------------------
    def get_game_cfgs(self):
        cfgs = self.get_attribute("play_cfg")
        return cfgs

    # -----------------------------
    # returns version of game-spec-file
    def get_version_string(self):
        if not self.gs:
            return ""
        return self.gs["version"]

    # -----------------------------
    # returns symbol-enum configuration
    def get_reel_symbol_enum(self):
        if not self.reels:
            return []
        # extract/generate symbol-enums ..
        symbol_enums = self.reels["symbol_enum"]
        sym_list = symbol_enums.split(",")
        return sym_list

    # -----------------------------
    # returns reels-configuration (returning a set (list of dicts) of reels)
    def get_reel_set(self):
        if not self.reels:
            return []
        # extract/generate symbol-enums ..
        reel_set = self.reels["reel_set"]
        return reel_set

    # --------------------------------
    @staticmethod
    def __validate_stripe_symbols(symbols, reel_set):
        unknown_symbols = []
        for r in reel_set:
            stripes = r["stripes"]
            for s_idx, s in enumerate(stripes):
                s_list = s.split(',')
                for e in s_list:
                    try:
                        sym_id = symbols.index(e)
                    except ValueError:
                        unknown_symbols.append(e)
        return unknown_symbols

    # --------------------------------
    def __validate_stripe_check_sums(self, symbols, reel_set):
        all_check_sums = []
        all_check_sums_ok = []
        for r in reel_set:
            rcs = []
            cs_ok = []
            stripes = r["stripes"]
            cfg_cs = r["check_sums"]
            for s_idx, s in enumerate(stripes):
                is_cs = 0
                should_cs = int(cfg_cs[s_idx], 16)
                s_list = s.split(',')
                for e_idx, e in enumerate(s_list):
                    if e_idx >= len(self.__primes):
                        raise IndexError("Not enough primes !!")
                    sym_id = symbols.index(e) + 1
                    is_cs += sym_id * self.__primes[e_idx]
                cs_ok.append(is_cs == should_cs)
                rcs.append(is_cs)
            all_check_sums.append(rcs)
            all_check_sums_ok.append(cs_ok)
        return [all_check_sums, all_check_sums_ok]

    # -----------------------------
    def __validity_check(self):
        return False
        # check check-sums vs. stripes
        #symbols = self.get_reel_symbol_enum()
        #reel_set = self.get_reel_set()

        # check all stripes containing only symbols from symbol-list
        #unknown_symbols = self.__validate_stripe_symbols(symbols, reel_set)

        #stripe_validation = self.__validate_stripe_check_sums(symbols, reel_set)
        #if not all([all(l) for l in stripe_validation[1]]):
        #    self.logger.error("Stripe validation failed:" + str(stripe_validation))
        #    #raise Exception("Stripe-Checksums not ok")


        # check for stripes shorter than window_sizes
        #window_sizes_ok = False
